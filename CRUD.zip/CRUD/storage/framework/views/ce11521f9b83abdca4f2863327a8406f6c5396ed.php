<?php $__env->startSection('content'); ?>
<h1 align="center">Welcome To My CRUD Operation</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>