<?php $__env->startSection('content'); ?>
<div class="col-md-2"></div>
<form method="post" action="<?php echo e(url('/form-save')); ?>"> <?php echo e(csrf_field()); ?>

  <div class="form-group">
    <label for="exampleInputEmail1">Name</label>
    <input type="text" name="name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Name">
    
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Number</label>
    <input type="text" name="number" class="form-control" id="exampleInputPassword1" placeholder="Number">
  </div>
  <div class="form-check">
    <input type="checkbox" name="check" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Check me out</label>
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
<div class="col-md-2"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>