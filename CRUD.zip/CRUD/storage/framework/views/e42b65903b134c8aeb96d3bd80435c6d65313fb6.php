<?php $__env->startSection('content'); ?>

<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">Number</th>
      <th>Update</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $show; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $show): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($show->id); ?></th>
      <td><?php echo e($show->name); ?></td>
      <td><?php echo e($show->number); ?></td>
      <td>
        <a href="<?php echo e(url('/edit/'.$show->id)); ?>">Edit</a>
        <a href="<?php echo e(url('/delete/'.$show->id)); ?>">Delete</a>
      </td>
      
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>