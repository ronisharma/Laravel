<?php $__env->startSection('content'); ?>
<div class="col-md-2"></div>
<form method="post" action="<?php echo e(url('/editsave')); ?>"> <?php echo e(csrf_field()); ?>

  <div class="form-group">
    <label for="exampleInputEmail1">Name</label>
    <input type="text" name="name" value="<?php echo e($data->name); ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Name">
     <input type="hidden" name="id" value="<?php echo e($data->id); ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Name">
    
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Number</label>
    <input type="text" name="number" value="<?php echo e($data->number); ?>" class="form-control" id="exampleInputPassword1" placeholder="Number">
  </div>
  
  <button type="submit" class="btn btn-primary">Update</button>
</form>
<div class="col-md-2"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>