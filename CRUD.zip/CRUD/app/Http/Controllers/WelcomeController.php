<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Student;

class WelcomeController extends Controller
{
	public function insert()
	{
		return view('insert');
	}
    public function formSave(Request $request)
    {
    	if($request->isMethod('post'))
    	{
    		$data = $request->all();
    		$student = new Student;
    		$student->name = $data['name'];
    		$student->number = $data['number'];
    		$student->save();

    		return redirect('/show');
    	}
    }
    public function show()
    {
    	$show = Student::get();
    	//var_dump($show);die;
    	return view('showstudent')->with(compact('show'));
    }
    public function edit($id)
    {
    	$data = Student::find($id);
    	return view('editstudent')->with(compact('data'));
    }
    public function editSave(Request $request)
    {	
    	$data = $request->all();
    	//var_dump($data);die;
    	$edit = Student::find($request->id);
    	$edit->name = $data['name'];
    	$edit->number = $data['number'];
    	$edit->save();
    	return redirect('/show');
    }
    public function delete($id)
    {
    	Student::find($id)->delete();
    	return redirect('/show');
    }
}
