@extends('index')
@section('content')
<h1 align="center">Welcome To My CRUD Operation</h1>
@endsection