@extends('index')
@section('content')

<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">Number</th>
      <th>Update</th>
    </tr>
  </thead>
  <tbody>
  @foreach($show as $show)
    <tr>
      <th scope="row">{{$show->id}}</th>
      <td>{{$show->name}}</td>
      <td>{{$show->number}}</td>
      <td>
        <a href="{{url('/edit/'.$show->id)}}">Edit</a>
        <a href="{{url('/delete/'.$show->id)}}">Delete</a>
      </td>
      
    </tr>
@endforeach
  </tbody>
</table>
@endsection