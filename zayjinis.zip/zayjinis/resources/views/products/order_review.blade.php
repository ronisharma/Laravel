@extends('layouts.fontendLayout.fontend_layout')
@section('content')
	
	<section id="form" style="margin-top: 10px;"><!--form-->
		<div class="container">
			<div class="breadcrumbs">
				<ol class="breadcrumb">
				  <li><a href="#">Home</a></li>
				  <li class="active">Order Review</li>
				</ol>
			</div>
			<div class="row">
				<div class="col-sm-4 col-sm-offset-1">
					<div class="login-form"><!--login form-->
						<h3>Billing Address</h3>		
						<div class="form-group">				
							{{$userDetails->name}}
						</div>
						<div class="form-group">
							{{$userDetails->address}}
						</div>
						<div class="form-group">
							{{$userDetails->country}}
						</div>
						<div class="form-group">
							{{$userDetails->city}}
						</div>
						<div class="form-group">
							{{$userDetails->state}}
						</div>
						
						<div class="form-group">
						{{$userDetails->pincode}}
						</div>
						<div class="form-group">
							{{$userDetails->mobile}}
						</div>
					</div>
				</div>
				<div class="col-sm-1">
					<h3 class="or">OR</h3>
				</div>
				<div class="col-sm-4">
					<div class="signup-form"><!--sign up form-->
						<h3>Shipping Address</h3>						
						  <div class="form-group">				
							{{$shippingDetails->name}}
						   </div>
						<div class="form-group">
							{{$shippingDetails->address}}
						</div>
						<div class="form-group">
							{{$shippingDetails->country}}
						</div>
						<div class="form-group">
							{{$shippingDetails->city}}
						</div>
						<div class="form-group">
							{{$shippingDetails->state}}
						</div>
						<div class="form-group">
							{{$shippingDetails->pincode}}
						</div>
						<div class="form-group">
							{{$shippingDetails->mobile}}
						</div>	
							
					</div>
				</div>
			</div>
			<!--start review here-->
	<section id="cart_items">
		<div class="container">			
			<div class="review-payment">
				<h2>Review & Payment</h2>
			</div>
			<div class="table-responsive cart_info">
				<table class="table table-condensed">
					<thead>
						<tr class="cart_menu">
							<td class="image">Item</td>
							<td class="description"></td>
							<td class="price">Price</td>
							<td class="quantity">Quantity</td>
							<td class="total">Total</td>
							
						</tr>
					</thead>
					<tbody>
						<?php $total_amount = 0; ?>
						@foreach($userCart as $cart)
						<tr>
							<td class="cart_product">
								<a href=""><img style="width:100px;" src="{{ asset('/public/backend/products/small_image/'.$cart->image) }}" alt=""></a>
							</td>
							<td class="cart_description">
								<h4><a href="">{{ $cart->product_name }}</a></h4>
								<p>Product Code: {{ $cart->product_code }}</p>
							</td>
							<td class="cart_price">
								<p>TK {{ $cart->price }}</p>
							</td>
							<td class="cart_quantity">
								<div class="cart_quantity_button">
									{{ $cart->quantity }}
								</div>
							</td>
							<td class="cart_total">
								<p class="cart_total_price">TK {{ $cart->price*$cart->quantity }}</p>
							</td>
							
						</tr>
						<?php $total_amount = $total_amount + ($cart->price*$cart->quantity); ?>
						@endforeach
						<tr>
							<td colspan="4">&nbsp;</td>
							<td colspan="2">
								<table class="table table-condensed total-result">
									<tr>
										<td>Cart Sub Total</td>
										<td>Tk {{$total_amount}}</td>
									</tr>
									<tr>
										<td>Discount (-)</td>
										<td>
											@if(!empty(Session::get('couponAmount')))
											Tk {{Session::get('couponAmount')}}
											@else
												Tk 0
											@endif
										</td>
									</tr>
									<tr class="shipping-cost">
										<td>Shipping Cost (+)</td>
										<td>Tk 0</td>										
									</tr>
									<tr>
										<td>Grand Total</td>
										<td><span>Tk {{$grand_total = $total_amount - Session::get('couponAmount')}}</span></td>
									</tr>
								</table>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			<form method="post" action="{{url('/place-order')}}">{{csrf_field()}}
				<div class="payment-options">
					<span>
						<input type="hidden" name="grand_total" value="{{$grand_total}}">
						<label><strong>Select Payment Method</strong></label>
					</span>
					<span>
						<label><input type="radio" name="payment" id="bkash" value="bkash"><b> bkash</b></label>
					</span>
					<span>
						<label><input type="radio" name="payment" id="cod" value="cod"><b> Cash-on Delivery</b></label>
					</span>
					<span>
						<button class="btn btn-success" onclick="return placeorder()" style="float: right;">Place Order</button>
					</span>
				</div>
			</form>
		</div>
	</section><!--end review here-->
		
		</div>
	</section>

@endsection
	
	