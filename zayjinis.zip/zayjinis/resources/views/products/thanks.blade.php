@extends('layouts.fontendLayout.fontend_layout')
@section('content')
	<section id="cart_items">
		<div class="container">
			<div class="breadcrumbs">
				<ol class="breadcrumb">
				  <li><a href="#">Home</a></li>
				  <li class="active">Thanks</li>
				</ol>
			</div>
		</div>
	</section> <!--/#cart_items-->
	<section id="do_action" style="text-align: center;">
		<div class="container">
			<div class="heading">
				<h3>Your Order Has Been Placed</h3>
				<p>Yore Order Number is #0{{Session::get('order_id')}}# and Total Payable is {{Session::get('grand_total')}} Tk</p>
			</div>
		</div>
	</section><!--/#do_action-->
@endsection

<?php
Session::forget('order_id');
Session::forget('grand_total');
?>