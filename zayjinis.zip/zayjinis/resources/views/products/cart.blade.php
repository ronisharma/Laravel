@extends('layouts.fontendLayout.fontend_layout')
@section('content')
		<!-- BREADCRUMB -->
	<div id="breadcrumb">
		<div class="container">
			<ul class="breadcrumb">
				<li><a href="#">Home</a></li>
				<li class="active">Shopping Cart</li>
			</ul>
		</div>
	</div>
	<!-- /BREADCRUMB -->

	<!-- section -->
	<div class="section">
		<!-- container -->
		<div class="container">
			<!-- row -->
			@if(Session::has('flash_message_success'))
		            <div class="alert alert-success alert-block">
		                <button type="button" class="close" data-dismiss="alert">×</button> 
		                    <strong>{!! session('flash_message_success') !!}</strong>
		            </div>
		        @endif
		        @if(Session::has('flash_message_error'))
		            <div class="alert alert-error alert-block" style="background-color:#f4d2d2">
		                <button type="button" class="close" data-dismiss="alert">×</button> 
		                    <strong>{!! session('flash_message_error') !!}</strong>
		            </div>
        		@endif
			<div class="row">
				<form id="checkout-form" class="clearfix">
					<div class="col-md-12">
						<div class="order-summary clearfix">
							<div class="section-title">
								<h3 class="title">Cart Product</h3>
							</div>
							<table class="shopping-cart-table table">
								<thead>
									<tr>
										<th>Product</th>
										<th></th>
										<th class="text-center">Price</th>
										<th class="text-center">Quantity</th>
										<th class="text-center">Total</th>
										<th class="text-right">Remove</th>
									</tr>
								</thead>
								<tbody>
									<?php $total_amount = 0; ?>
									@foreach($userCart as $cart)
									<tr>
										<td class="thumb"><img src="{{asset('public/backend/products/small_image/'.$cart->image)}}" alt=""></td>
										<td class="details">
											<a href="#">{{$cart->product_name}}</a>
											<ul>
												<li><span>Size: {{$cart->size}}</span></li>
												<li><span>Color:{{$cart->product_color}}</span></li>
											</ul>
										</td>
										<td class="price text-center"><strong>Tk {{$cart->price}}</strong></td>
										<td class="qty text-center">
										<a class="cart_quantity_up" href="{{ url('/cart/update-quantity/'.$cart->id.'/1') }}"><b> + </b></a>
										<input class="input" type="text" value="{{$cart->quantity}}" autocomplete="off" size="1">
										@if($cart->quantity>1)
											<a class="cart_quantity_down" href="{{ url('/cart/update-quantity/'.$cart->id.'/-1') }}"><b> - </b></a>
										@endif
										</td>
										<td class="total text-center"><strong class="primary-color">TK {{ $cart->price*$cart->quantity }}</strong></td>
										<td class="text-right">
										<a class="cart_quantity_delete" href="{{ url('/cart/delete-product/'.$cart->id) }}"><i class="fa fa-close"></i>
										</a></td>
									</tr>
									<?php $total_amount = $total_amount + ($cart->price*$cart->quantity); ?>
									@endforeach
								</tbody>
								<tfoot>
									<tr>
										<th class="empty" colspan="3"></th>
										<th>SUBTOTAL</th>
										<th colspan="2" class="sub-total">Tk. <?php echo $total_amount; ?></th>
									</tr>
									<tr>
										<th class="empty" colspan="3"></th>
										<th>SHIPING</th>
										<td colspan="2">Free Shipping</td>
									</tr>
									<tr>
										<th class="empty" colspan="3"></th>
										<th>TOTAL</th>
										<th colspan="2" class="total">Tk. <?php echo $total_amount; ?></th>
									</tr>
								</tfoot>
							</table>
							<div class="pull-right">
								@if($total_amount > 0)
								<a class="primary-btn" href="{{url('/checkout')}}">Check Out</a>
								@endif
							</div>
						</div>

					</div>
				</form>
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</div>
	<!-- /section -->
@endsection