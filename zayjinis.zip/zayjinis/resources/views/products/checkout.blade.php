@extends('layouts.fontendLayout.fontend_layout')
@section('content')
	
	<section id="form" style="margin-top: 10px;"><!--form-->
		<div class="container">
			@if(Session::has('flash_message_success'))
            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button> 
                    <strong>{!! session('flash_message_success') !!}</strong>
            </div>
       		@endif
			@if(Session::has('flash_message_error'))
            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button> 
                    <strong>{!! session('flash_message_error') !!}</strong>
            </div>
       		@endif
		<form action="{{url('/checkout')}}" method="post" id="checkoutform" name="checkoutform">{{csrf_field()}}
			<div class="row">
				<div class="col-sm-4 col-sm-offset-1">
					<div class="login-form"><!--login form-->
						<h3>Billing TO</h3>		
						<div class="form-group">				
							<input type="text" name="billing_name" @if(!empty($userDetails->name)) value="{{$userDetails->name}}" @endif id="billing_name" class="form-control" placeholder="Enter Name" />
						</div>
						<div class="form-group">
							<input type="text" name="billing_address" @if(!empty($userDetails->address)) value="{{$userDetails->address}}" @endif id="billing_address" class="form-control" placeholder="Enter Address" />
						</div>
						<div class="form-group">
							<select name="billing_country" id="billing_country" class="form-control">
								@foreach($countries as $country)
								<option value="{{ $country->country_name }}" @if(!empty($userDetails->country) && $country->country_name == $userDetails->country) selected @endif>{{ $country->country_name }}</option>
								@endforeach
							</select>
						</div>
						<div class="form-group">
							<input type="text" name="billing_city" @if(!empty($userDetails->city)) value="{{$userDetails->city}}" @endif id="billing_city" class="form-control" placeholder="Enter City" />
						</div>
						<div class="form-group">
							<input type="text" name="billing_state" @if(!empty($userDetails->state)) value="{{$userDetails->state}}" @endif id="billing_state" class="form-control" placeholder="Enter State" />
						</div>
						
						<div class="form-group">
							<input type="text" name="billing_pincode" @if(!empty($userDetails->pincode)) value="{{$userDetails->pincode}}" @endif id="billing_pincode" class="form-control" placeholder="Enter Pincode" />
						</div>
						<div class="form-group">
							<input type="text" name="billing_mobile" @if(!empty($userDetails->mobile)) value="{{$userDetails->mobile}}" @endif id="billing_mobile" class="form-control" placeholder="Enter Mobile" />
						</div>
						<input type="checkbox" name="billtoship" id="billtoship" value="1">&nbsp;<b>Shipping Address same as Billing Address</b>
					</div>
				</div>
				<div class="col-sm-1">
					<h3 class="or">OR</h3>
				</div>
				<div class="col-sm-4">
					<div class="signup-form"><!--sign up form-->
						<h3>Shipping TO</h3>						
							<div class="form-group">				
							<input type="text" name="shipping_name" id="shipping_name" class="form-control" placeholder="Enter Name" @if(!empty($shippingDetails->name))value="{{$shippingDetails->name}}" @endif  />
						</div>
						<div class="form-group">
							<input type="text" name="shipping_address" id="shipping_address" class="form-control" placeholder="Enter Address" @if(!empty($shippingDetails->address))value="{{$shippingDetails->address}}" @endif/>	
						</div>
						<div class="form-group">
							<select name="shipping_country" id="shipping_country" class="form-control">
								<option value="">Select one</option>
								@foreach($countries as $country)
								<option value="{{ $country->country_name }}" @if(!empty($shippingDetails->country) && $shippingDetails->country==$country->country_name) selected @endif>{{ $country->country_name }}</option>
								@endforeach
							</select>
						</div>
						<div class="form-group">
							<input type="text" name="shipping_city" id="shipping_city" class="form-control" placeholder="Enter City" @if(!empty($shippingDetails->city))value="{{$shippingDetails->city}}" @endif/>
						</div>
						<div class="form-group">
							<input type="text" name="shipping_state" id="shipping_state" class="form-control" placeholder="Enter State" @if(!empty($shippingDetails->state))value="{{$shippingDetails->state}}" @endif/>
						</div>
						<div class="form-group">
							<input type="text" name="shipping_pincode" id="shipping_pincode" class="form-control" placeholder="Enter Pincode" @if(!empty($shippingDetails->pincode))value="{{$shippingDetails->pincode}}" @endif/>
						</div>
						<div class="form-group">
							<input type="text" name="shipping_mobile" id="shipping_mobile" class="form-control" placeholder="Enter Mobile" @if(!empty($shippingDetails->mobile))value="{{$shippingDetails->mobile}}" @endif/>
						</div>	
						<button class="btn btn-success">Checkout</button>		
					</div>
				</div>
			</div>
			</form>
		</div>
	</section><!--/form-->

@endsection
	
	