@extends('layouts.fontendLayout.fontend_layout')
@section('content')
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css">
	<section id="cart_items">
		<div class="container">
			<div class="breadcrumbs">
				<ol class="breadcrumb">
				  <li><a href="{{url('/')}}">Home</a></li>
				  <li class="active">User Order</li>
				</ol>
			</div>
		</div>
	</section> <!--/#cart_items-->
	<section id="do_action">
		<div class="container">
			<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Order Id</th>
                <th>Order Product</th>
                <th>Payment Method</th>
                <th>Grand Total</th>
                <th>Created On</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        	@foreach($orderDetails as $value)
            <tr>
                <td>{{$value->id}}</td>
                <td>
                	@foreach($value->orders as $pro)
                		 {{$pro->product_code}}<br>
                	@endforeach
                </td>
                <td>{{$value->payment_method}}</td>
                <td>{{$value->grand_total}}</td>
                <td>{{$value->created_at}}</td>
                <td><a href="{{url('/user-order/'.$value->id)}}">View</a></td>
            </tr>
            @endforeach
        </tbody>
       
    </table>
		</div>
	</section><!--/#do_action-->

@endsection