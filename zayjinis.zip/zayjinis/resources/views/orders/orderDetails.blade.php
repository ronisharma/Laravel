@extends('layouts.fontendLayout.fontend_layout')
@section('content')
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css">
	<section id="cart_items">
		<div class="container">
			<div class="breadcrumbs">
				<ol class="breadcrumb">
				  <li><a href="{{url('/')}}">Home</a></li>
				  <li class="active"><a href="{{url('/user-order')}}">Order</a></li>
                  <li>{{$orderDetails->id}}</li>
				</ol>
			</div>
		</div>
	</section> <!--/#cart_items-->
	<section id="do_action">
		<div class="container">
			<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Product Name</th>
                <th>Product Code</th>
                <th>Product Size</th>
                <th>Product Color</th>
                <th>Product Price</th>
                <th>Product Qty</th>
            </tr>
        </thead>
        <tbody>
        	@foreach($orderDetails->orders as $value)
            <tr>
                <td>{{$value->product_name}}</td>
                <td>{{$value->product_code}}</td>
                <td>{{$value->product_size}}</td>
                <td>{{$value->product_color}}</td>
                <td>{{$value->product_price}}</td>
                <td>{{$value->product_qty}}</td>
            </tr>
            @endforeach
        </tbody>
       
    </table>
		</div>
	</section><!--/#do_action-->

@endsection