<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Welcome to Zayjinis online Shopping</title>
    <!-- Google font -->
    <link href="https://fonts.googleapis.com/css?family=Hind:400,700" rel="stylesheet">
    <!-- Bootstrap -->
    <link type="text/css" rel="stylesheet" href="{{asset('public/fontend/css/bootstrap.min.css')}}" />
    <!-- Slick -->
    <link type="text/css" rel="stylesheet" href="{{asset('public/fontend/css/slick.css')}}" />
    <link type="text/css" rel="stylesheet" href="{{asset('public/fontend/css/slick-theme.css')}}" />
    <!-- nouislider -->
    <link type="text/css" rel="stylesheet" href="{{asset('public/fontend/css/nouislider.min.css')}}" />
    <!-- Font Awesome Icon -->
    <link rel="stylesheet" href="{{asset('public/fontend/css/font-awesome.min.css')}}">
    <!-- Custom stlylesheet -->
    <link type="text/css" rel="stylesheet" href="{{asset('public/fontend/css/style.css')}}" />

    <link type="text/css" rel="stylesheet" href="{{asset('public/fontend/css/custom.css')}}" />

    <script src="http://code.jquery.com/jquery-1.10.2.js"></script>
    <script src="http://code.jquery.com/ui/1.11.2/jquery-ui.js"></script>

    <script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>

</head>

<body>
    @include('layouts.fontendLayout.fontend_header')
    @yield('content')
    @include('layouts.fontendLayout.fontend_footer')
    <!-- jQuery Plugins -->
    <script src="{{asset('public/fontend/js/jquery.min.js')}}"></script>
    
    <script src="{{asset('public/fontend/js/bootstrap.min.js')}}"></script>
    <script src="{{asset('public/fontend/js/slick.min.js')}}"></script>
    <script src="{{asset('public/fontend/js/nouislider.min.js')}}"></script>
    <script src="{{asset('public/fontend/js/jquery.zoom.min.js')}}"></script>
    <script src="{{asset('public/fontend/js/jquery.validate.js')}}"></script>
    <script src="{{asset('public/fontend/js/main.js')}}"></script>


    

</body>

</html>
