<?php
use App\Models\CategoryModel;
use App\Http\Controllers\Controller;
use App\Http\Controllers\IndexController;

$mainCategories = Controller::mainCategories();
$cart = IndexController::carts();
//var_dump($cart);exit();
?>
<!-- HEADER -->
    <header>
        <!-- top Header -->
        <div id="top-header">
            <div class="container">
                <div class="pull-left">
                    <span><marquee>শীঘ্রই শুভ উদ্বোধন হচ্ছে Zayjinis.com</marquee></span>
                </div>
                <div class="pull-right">
                    <ul class="footer-social">
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                        <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- /top Header -->

        <!-- header -->
        <div id="header">
            <div class="container">
                <div class="pull-left">
                    <!-- Logo -->
                    <div class="header-logo">
                        <a class="logo" href="{{url('/')}}">
                            <img src="{{asset('public/fontend/logo.png')}}" alt="">
                        </a>
                    </div>
                    <!-- /Logo -->

                    <!-- Search -->
                    <div class="header-search">
                        <form method="post" action="{{url('/search-product')}}">{{csrf_field()}}
                            <input class="input search-input" type="text" name="name" placeholder="Enter your keyword">
                            <select name="cat_id" class="input search-categories">
                                <option value="0">Select One</option>
                                @foreach($mainCategories as $category)
                                <option value="{{$category->id}}">{{$category->name}}</option>
                                @endforeach
                            </select>
                            <button class="search-btn"><i class="fa fa-search"></i></button>
                        </form>
                    </div>
                    <!-- /Search -->
                </div>
                <div class="pull-right">
                    <ul class="header-btns">
                        <!-- Account -->
                        <li class="header-account dropdown default-dropdown">
                            <div class="dropdown-toggle" role="button" data-toggle="dropdown" aria-expanded="true">
                                <div class="header-btns-icon">
                                    <i class="fa fa-user-o"></i>
                                </div>
                                <strong class="text-uppercase">My Account <i class="fa fa-caret-down"></i></strong>
                            </div>
                            @if(empty(Auth::check()))
                            <a href="{{url('/login-register')}}" class="text-uppercase">Login</a> / <a href="{{url('/login-register')}}" class="text-uppercase">Join</a>
                            @else
                            <a href="{{url('/user-logout')}}" class="text-uppercase">LogOut</a>
                            @endif
                            <ul class="custom-menu">
                                @if(empty(Auth::check()))
                                <li><a href="{{url('/login-register')}}"><i class="fa fa-unlock-alt"></i> Login</a></li>
                                <li><a href="{{url('/login-register')}}"><i class="fa fa-user-plus"></i> Create An Account</a>
                                </li>
                                @else
                                <li><a href="{{url('/account')}}"><i class="fa fa-user-o"></i> My Account</a></li>
                                <li><a href="{{url('/user-order')}}"><i class="fa fa-heart-o"></i> My Order</a></li>
                                <li><a href="{{url('/user-logout')}}"><i class="fa fa-key-o"></i> Logout</a></li>
                                @endif
                            </ul>
                        </li>
                        <!-- /Account -->

                        <!-- Cart -->
                        <li class="header-cart dropdown default-dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
                                <div class="header-btns-icon">
                                    <i class="fa fa-shopping-cart"></i>
                                    <!-- <span class="qty"></span> -->
                                </div>
                                <strong class="text-uppercase">My Cart:</strong>
                                <br>
                                <span>{{Session::get('grand_total')}}</span>
                            </a>
                            <div class="custom-menu">
                                <div id="shopping-cart">
                                    <div class="shopping-cart-list">
                                        @foreach ($cart as $value)
                                        <div class="product product-widget">
                                            <div class="product-thumb">
                                                <img src="{{asset('public/backend/products/small_image/'.$value->image)}}" alt="">
                                            </div>
                                            <div class="product-body">
                                                <h3 class="product-price">Tk. {{$value->price}} <span class="qty">x {{$value->quantity}}</span></h3>
                                                <h2 class="product-name"><a href="#">{{$value->product_name}}</a></h2>
                                            </div>
                                            
                                        </div>
                                        @endforeach
                                        <!-- <div class="product product-widget">
                                            <div class="product-thumb">
                                                <img src="{{asset('public/fontend/img/thumb-product01.jpg')}}" alt="">
                                            </div>
                                            <div class="product-body">
                                                <h3 class="product-price">$32.50 <span class="qty">x3</span></h3>
                                                <h2 class="product-name"><a href="#">Product Name Goes Here</a></h2>
                                            </div>
                                            <button class="cancel-btn"><i class="fa fa-trash"></i></button>
                                        </div> -->
                                    </div>
                                    <div class="shopping-cart-btns">
                                        <button class="primary-btn"><a href="{{url('/cart')}}">View Cart</a></button>
                                        <button class="primary-btn"><a href="{{url('/checkout')}}">Checkout <i class="fa fa-arrow-circle-right"></i></a></button>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <!-- /Cart -->

                        <!-- Mobile nav toggle-->
                        <li class="nav-toggle">
                            <button class="nav-toggle-btn main-btn icon-btn"><i class="fa fa-bars"></i></button>
                        </li>
                        <!-- / Mobile nav toggle -->
                    </ul>
                </div>
            </div>
            <!-- header -->
        </div>
        <!-- container -->
    </header>
    <!-- /HEADER -->

    <!-- NAVIGATION -->
    <div id="navigation">
        <!-- container -->
        <div class="container">
            <div id="responsive-nav">
                <!-- category nav -->
                <div class="category-nav @if($navbar=='')show-on-click @endif">
                    <span class="category-header">Categories <i class="fa fa-list"></i></span>
                    <ul class="category-list">
                    	@foreach($mainCategories as $category)
                        <li class="dropdown side-dropdown">
                            <a class="dropdown-toggle" href="hello" data-toggle="dropdown" aria-expanded="true">{{$category->name}}<i class="fa fa-angle-right"></i></a>
                            <div class="custom-menu">
                                <div class="row">
                                    <div class="col-md-12">
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">Subcategory</h3></li>
                                            @foreach($category->categories as $subcategory)
                                            <li><a href="{{url('/product/'.$subcategory->url)}}">{{$subcategory->name}}</a></li>
                                            @endforeach
                                        </ul>
                                        <hr class="hidden-md hidden-lg">
                                    </div>
                                </div>
                                
                            </div>
                        </li>
                        @endforeach
				 <!--   <li><a href="#">Category two</a></li>
                        <li class="dropdown side-dropdown"><a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">Category Three <i class="fa fa-angle-right"></i></a>
                            <div class="custom-menu">
                                <div class="row">
                                    <div class="col-md-4">
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">Subcategory</h3></li>
                                            <li><a href="#">Women’s Clothing</a></li>
                                            <li><a href="#">Men’s Clothing</a></li>
                                            <li><a href="#">Phones & Accessories</a></li>
                                            <li><a href="#">Jewelry & Watches</a></li>
                                            <li><a href="#">Bags & Shoes</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li><a href="#">Category Four</a></li>
                        <li><a href="#">Category Five</a></li> -->
                        
                    </ul>
                </div>
                <!-- /category nav -->

                <!-- menu nav -->
                <div class="menu-nav">
                    <span class="menu-header">Menu <i class="fa fa-bars"></i></span>
                    <ul class="menu-list">
                        <li><a href="{{url('/')}}">Home</a></li>
                        <li><a href="#">About Us</a></li>
                        <li class="dropdown default-dropdown"><a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">Shop <i class="fa fa-caret-down"></i></a>
                            <ul class="custom-menu">
                                @foreach($mainCategories as $category)
                                <li><a href="{{url('product/'.$category->url)}}">{{$category->name}}</a></li>
                                @endforeach
                            </ul>
                        </li>
                        <li><a href="#">Contact Us</a></li>
                    </ul>
                </div>
                <!-- menu nav -->
            </div>
        </div>
        <!-- /container -->
    </div>
    <!-- /NAVIGATION -->
    <style type="text/css">
        .pull-left {
            float: left;
            width: 70%;
        }
        .pull-left span{
            color: green;
        }
    </style>