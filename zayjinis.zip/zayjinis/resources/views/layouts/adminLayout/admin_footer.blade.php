
<!--Footer-part-->

<div class="row-fluid">
  <div id="footer" class="span12"> 2018 &copy; Admin Panel. Developed by <a href="#">Roni Sharma</a> </div>
</div>

<!--end-Footer-part-->