<!DOCTYPE html>
<html lang="en">
<head>
<title>Matrix Admin</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<!-- <link rel="stylesheet" href="{{asset('public/backend/css/bootstrap.min.css')}}" />
<link rel="stylesheet" href="{{asset('public/backend/css/bootstrap-responsive.min.css')}}" />
<link rel="stylesheet" href="{{asset('public/backend/css/fullcalendar.css')}}" />
<link rel="stylesheet" href="{{asset('public/backend/css/matrix-style.css')}}" />
<link rel="stylesheet" href="{{asset('public/backend/css/matrix-media.css')}}" />
<link href="{{asset('public/backend/font-awesome/css/font-awesome.css')}}" rel="stylesheet" />
<link rel="stylesheet" href="{{asset('public/backend/css/jquery.gritter.css')}}" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'> -->
<link rel="stylesheet" href="{{asset('public/backend/css/bootstrap.min.css')}}" />
<link rel="stylesheet" href="{{asset('public/backend/css/bootstrap-responsive.min.css')}}" />
<link rel="stylesheet" href="{{asset('public/backend/css/uniform.css')}}" />
<link rel="stylesheet" href="{{asset('public/backend/css/select2.css')}}" />
<link rel="stylesheet" href="{{asset('public/backend/css/matrix-style.css')}}" />
<link rel="stylesheet" href="{{asset('public/backend/css/matrix-media.css')}}" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">
<link href="{{asset('public/backend/font-awesome/css/font-awesome.css')}}" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

<!--  -->
</head>
<body>
@include('layouts.adminLayout.admin_header');
@include('layouts.adminLayout.admin_sidebar');

<!--main-container-part-->
@yield('content')
<!--end-main-container-part-->

@include('layouts.adminLayout.admin_footer');

<!-- <script src="{{asset('public/backend/js/excanvas.min.js')}}"></script> 
<script src="{{asset('public/backend/js/jquery.min.js')}}"></script> 
<script src="{{asset('public/backend/js/jquery.ui.custom.js')}}"></script> 
<script src="{{asset('public/backend/js/bootstrap.min.js')}}"></script> 
<script src="{{asset('public/backend/js/jquery.flot.min.js')}}"></script> 
<script src="{{asset('public/backend/js/jquery.flot.resize.min.js')}}"></script> 
<script src="{{asset('public/backend/js/jquery.peity.min.js')}}"></script> 
<script src="{{asset('public/backend/js/fullcalendar.min.js')}}"></script> 
<script src="{{asset('public/backend/js/matrix.js')}}"></script> 
<script src="{{asset('public/backend/js/matrix.dashboard.js')}}"></script> 
<script src="{{asset('public/backend/js/jquery.gritter.min.js')}}"></script> 
<script src="{{asset('public/backend/js/matrix.interface.js')}}"></script> 
<script src="{{asset('public/backend/js/matrix.chat.js')}}"></script> 
<script src="{{asset('public/backend/js/jquery.validate.js')}}"></script> 
<script src="{{asset('public/backend/js/matrix.form_validation.js')}}"></script> 
<script src="{{asset('public/backend/js/jquery.wizard.js')}}"></script> 
<script src="{{asset('public/backend/js/jquery.uniform.js')}}"></script> 
<script src="{{asset('public/backend/js/select2.min.js')}}"></script> 
<script src="{{asset('public/backend/js/matrix.popover.js')}}"></script> 
<script src="{{asset('public/backend/js/jquery.dataTables.min.js')}}"></script> 
<script src="{{asset('public/backend/js/matrix.tables.js')}}"></script> --> 

<script src="{{asset('public/backend/js/jquery.min.js')}}"></script> 
<!-- <script src="{{asset('public/backend/js/jquery.ui.custom.js')}}"></script>  -->
<script src="{{asset('public/backend/js/bootstrap.min.js')}}"></script> 
<script src="{{asset('public/backend/js/jquery.uniform.js')}}"></script> 
<script src="{{asset('public/backend/js/select2.min.js')}}"></script> 
<script src="{{asset('public/backend/js/jquery.dataTables.min.js')}}"></script> 
<script src="{{asset('public/backend/js/jquery.validate.js')}}"></script> 
<script src="{{asset('public/backend/js/matrix.js')}}"></script> 
<script src="{{asset('public/backend/js/matrix.form_validation.js')}}"></script>
<script src="{{asset('public/backend/js/matrix.tables.js')}}"></script>
<script src="{{asset('public/backend/js/matrix.popover.js')}}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<script type="text/javascript">
  $( function() {
    $( "#expiry_date" ).datepicker({
      minDate: 0,
      dateFormat: 'yy-mm-dd'
    });
  } );
</script>
<!-- <script type="text/javascript">
  function goPage (newURL) {
      if (newURL != "") {
    
          if (newURL == "-" ) {
              resetMenu();            
          } 
          else {  
            document.location.href = newURL;
          }
      }
  }
function resetMenu() {
   document.gomenu.selector.selectedIndex = 2;
}
</script> -->
</body>
</html>
