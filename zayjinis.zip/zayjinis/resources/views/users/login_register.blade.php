@extends('layouts.fontendLayout.fontend_layout')
@section('content')
	
	<section id="form" style="margin-top: 10px;"><!--form-->
		<div class="container">
				<!-- BREADCRUMB -->
	<div id="breadcrumb">
		<div class="container">
			<ul class="breadcrumb">
				<li><a href="#">Home</a></li>
				<li class="active">Login - Registration</li>
			</ul>
		</div>
	</div><br>
	<!-- /BREADCRUMB -->
			<div class="row">
					@if(Session::has('flash_message_error'))
		            <div class="alert alert-success alert-block">
		                <button type="button" class="close" data-dismiss="alert">×</button> 
		                    <strong>{!! session('flash_message_error') !!}</strong>
		            </div>
		       		@endif
				<div class="col-sm-4 col-sm-offset-1">
					<div id="checkout-form" class="login-form"><!--login form-->
						<h3>Login to your account</h3>
						<form action="{{url('/user-login')}}" method="post" id="loginform" name="loginform">{{csrf_field()}}
							<div class="from-group">
							<input type="email" name="email" class="form-control" placeholder="Enter Email" />
							</div><br>
							<div class="from-group">
							<input type="password" name="password" class="form-control" placeholder="Enter Password" /><br>
							</div>
							<!-- <span>
								<input type="checkbox" class="checkbox"> 
								Keep me signed in
							</span> -->
							<div class="from-group">
							<button type="submit" class="btn btn-default">Login</button>
							</div>
						</form>
					</div><!--/login form-->
				</div>
				<div class="col-sm-1">
					<h3 class="or">OR</h3>
				</div>
				<div class="col-sm-4">
					<div class="signup-form"><!--sign up form-->
						<h3>New User Register!</h3>
						<form action="{{url('/user-register')}}" method="post" name="myform" id="myform">{{csrf_field()}}
							<div class="from-group">
							<input type="text" name="name" id="name" class="form-control" placeholder="Name"/>
							</div><br>
							<div class="from-group">
							<input type="email" name="email" id="email" class="form-control" placeholder="Email Address"/>
							</div><br>
							<div class="from-group">
							<input type="password" name="password" id="password" class="form-control" placeholder="Password"/>
							</div><br>
							<div class="from-group">
							<button type="submit" class="btn btn-default">Signup</button>
							</div>
						</form>
					</div><!--/sign up form-->
				</div>
			</div>
		</div>
	</section><!--/form-->
	
@endsection
	
	