@extends('layouts.fontendLayout.fontend_layout')
@section('content')
	
	<section id="form" style="margin-top: 50px;"><!--form-->
		<div class="container">
			<div class="row">
					@if(Session::has('flash_message_success'))
		            <div class="alert alert-success alert-block">
		                <button type="button" class="close" data-dismiss="alert">×</button> 
		                    <strong>{!! session('flash_message_success') !!}</strong>
		            </div>
		       		@endif
					@if(Session::has('flash_message_error'))
		            <div class="alert alert-success alert-block">
		                <button type="button" class="close" data-dismiss="alert">×</button> 
		                    <strong>{!! session('flash_message_error') !!}</strong>
		            </div>
		       		@endif
				<div class="col-sm-4 col-sm-offset-1">
					<div class="login-form"><!--login form-->
						<h3>Update account</h3>
						<form action="{{url('/account')}}" method="post" name="updateUser" id="updateUser">{{csrf_field()}}
							<input type="text" name="name" value="{{$userDetails->name}}" class="form-control" id="name" placeholder="Name"/><br>
							<input type="text" name="address" value="{{$userDetails->address}}" class="form-control" id="address" placeholder="Enter Address"/><br>
							<select name="country" class="form-control" id="country">
								<option value="">Select One</option>
								@foreach($countries as $country)
								<option value="{{ $country->country_name }}" @if($country->country_name==$userDetails->country) selected @endif >{{ $country->country_name }}</option>
								@endforeach
							</select><br>
							<input type="text" name="city" value="{{$userDetails->city}}" class="form-control" id="city" placeholder="city"><br>
							<input type="state" name="state" value="{{$userDetails->state}}" class="form-control" id="state" placeholder="state"><br>
							<input type="text" name="pincode" value="{{$userDetails->pincode}}" class="form-control" id="pincode" placeholder="pincode"><br>
							<input type="text" name="mobile" value="{{$userDetails->mobile}}" class="form-control" id="mobile" placeholder="Mobile"><br>
							<button type="submit" class="btn btn-default">Update</button>
						</form>
					</div><!--/login form-->
				</div>
				<div class="col-sm-1">
					<h3 class="or">OR</h3>
				</div>
				<div class="col-sm-4">
					<div class="signup-form"><!--sign up form-->
						<h3>Update Password</h3>
						<form action="{{url('/updateUserpwd')}}" method="post" name="updateuserPwd" id="updateuserPwd">{{csrf_field()}}
							<input type="password" name="current_pwd" class="form-control" id="current_pwd" placeholder="Current Password"/><br>
							<span id="pwdchk"></span>
							<input type="password" name="new_pwd" class="form-control" id="new_pwd" placeholder="New Password"><br>
							<input type="password" name="confirm_pwd" class="form-control" id="confirm_pwd" placeholder="Confirm Password"><br>
							<button type="submit" class="btn btn-default">Update Password</button>
						</form>
						
					</div><!--/sign up form-->
				</div>
			</div>
		</div>
	</section><!--/form-->

@endsection
	
	