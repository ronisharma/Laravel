@extends('layouts.adminLayout.admin_layout')
@section('content')
<div id="content">
  <div id="content-header">
    <div id="breadcrumb"> <a href="#" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#" class="current">view Product</a> </div>
    <h1>Product</h1>
  </div>
  	@if(Session::has('flash_message_success'))
	<div class="alert alert-success alert-block">
	    <button type="button" class="close" data-dismiss="alert">×</button> 
	        <strong>{!! session('flash_message_success') !!}</strong>
	</div>
	@endif
  <div class="container-fluid">
    <hr>
    <div class="row-fluid">
      <div class="span12">
        <div class="widget-box">
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
            <h5>View Product</h5>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-bordered data-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Product Name</th>
                  <th>Category Id</th>
                  <th>Category Name</th>
                  <th>Product Code</th>
                  <th>Product Price</th>
                  <th>Product Color</th>
                  <th>Image</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
              @foreach($products as $value)
                <tr class="gradeX">
                  <td>{{ $value->id }}</td>
                  <td>{{ $value->product_name }}</td>
                  <td>{{ $value->category_id }}</td>
                  <td>{{ $value->category }}</td>
                  <td>{{ $value->product_code }}</td>
                  <td>{{ $value->price }}</td>
                  <td>{{ $value->product_color }}</td>
                  <td>
                    @if(!empty($value->image))
                    <img src="{{asset('public/backend/products/small_image/'.$value->image)}}" style="width:50px;height: 50px;">
                    @endif
                  </td>
                  <td class="center">
                    <a href="#myModal{{ $value->id }}" data-toggle="modal" class="btn btn-success btn-mini">Details</a>
                    <a href="{{url('/admin/edit-product/'.$value->id)}}" class="btn btn-primary btn-mini">Edit</a> 
                    <a href="{{url('/admin/add-attribute/'.$value->id)}}" id="" class="btn btn-success btn-mini">Add</a>
                    <a href="{{url('/admin/add-images/'.$value->id)}}" id="" class="btn btn-primary btn-mini">Add Image</a>
                    <a rel="{{ $value->id }}" rel1="delete-product" href="javascript:" class="btn btn-danger btn-mini deleteRecord">Delete</a>
                  </td>
                </tr>
                <div id="myModal{{ $value->id }}" class="modal hide">
                  <div class="modal-header">
                    <button data-dismiss="modal" class="close" type="button">×</button>
                    <h3>{{ $value->product_name }} Description</h3>
                  </div>
                  <div class="modal-body">
                    <p>{{ $value->description }}</p>
                  </div>
                </div>
              @endforeach
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection