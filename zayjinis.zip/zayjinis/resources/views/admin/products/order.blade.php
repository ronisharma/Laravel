@extends('layouts.adminLayout.admin_layout')
@section('content')
<div id="content">
  <div id="content-header">
    <div id="breadcrumb"> <a href="#" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#" class="current">view Order</a> </div>
    <h1>Order</h1>
  </div>
  	@if(Session::has('flash_message_success'))
	<div class="alert alert-success alert-block">
	    <button type="button" class="close" data-dismiss="alert">×</button> 
	        <strong>{!! session('flash_message_success') !!}</strong>
	</div>
	@endif
  <div class="container-fluid">
    <div class="row-fluid">
      <div class="span12">
        <div class="widget-box">
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
            <h5>View Order</h5>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-bordered data-table">
              <thead>
                <tr>
                  <th>OrderID</th>
                  <th>Order Date</th>
                  <th>Customer Name</th>
                  <th>Customer Email</th>
                  <th>Ordered Product</th>
                  <th>Ordered Amount</th>
                  <th>Order Status</th>
                  <th>Payment Method</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
              @foreach($order as $value)
                <tr class="gradeX">
                  <td>{{ $value->id }}</td>
                  <td>{{ $value->created_at }}</td>
                  <td>{{ $value->name }}</td>
                  <td>{{ $value->user_email }}</td>
                  <td>
                      @foreach($value->orders as $pro)
                      {{$pro->product_code}} 
                      ({{$pro->product_qty}})
                      <br>
                      @endforeach
                  </td>
                  <td>{{ $value->grand_total }}</td>
                  <td>{{ $value->order_status }}</td>
                  <td>{{ $value->payment_method }}</td>
                 
                  <td class="center">
                    <a href="{{ url('admin/order-details/'.$value->id) }}" class="btn btn-success btn-mini">Details</a>
            
                    <a rel="{{ $value->id }}" rel1="delete-product" href="javascript:" class="btn btn-danger btn-mini deleteRecord">Delete</a>
                  </td>
                </tr>
               
              @endforeach
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection