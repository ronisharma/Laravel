@extends('layouts.adminLayout.admin_layout')
@section('content')
<!--main-container-part-->
<div id="content">
  <div id="content-header">
    <div id="breadcrumb"> <a href="{{url('/admin/dashboard')}}" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#" class="current">Order Details</a> </div>
    <h1>Order Id : #{{$order->id}}</h1>
  </div>
  <div class="container-fluid">
    <div class="row-fluid">
      <div class="span6">
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"><i class="icon-time"></i></span>
            <h5>Order Details</h5>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-striped table-bordered">
              <tbody>
                <tr>
                  <td class="taskDesc">Order Date</td>
                  <td class="taskStatus"><span class="in-progress">{{$order->created_at}}</span></td>
                </tr>
                <tr>
                  <td class="taskDesc">Order Status</td>
                  <td class="taskStatus"><span class="in-progress">{{$order->order_status}}</span></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="span6">
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"><i class="icon-time"></i></span>
            <h5>Customer Details</h5>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-striped table-bordered">
              <tbody>
                <tr>
                  <td class="taskDesc">Customer Name</td>
                  <td class="taskStatus"><span class="in-progress">{{$order->name}}</span></td>
                </tr>
                 <tr>
                  <td class="taskDesc">Customer Email</td>
                  <td class="taskStatus"><span class="in-progress">{{$order->user_email}}</span></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <div class="row-fluid">
      <div class="span6">
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"> <i class="icon-file"></i> </span>
            <h5>Billing Details</h5>
          </div>
          <div class="widget-content nopadding">
            <ul class="recent-posts">
              <li>
               Name: {{$order->name}} <br>
               Email: {{$order->user_email}} <br>
               Address: {{$order->address}} <br>
               Country: {{$order->country}} <br>
               City: {{$order->city}} <br>
               State: {{$order->state}} <br>
               Mobile: {{$order->mobile}} <br>
               Date: {{$order->created_at}} <br>
              </li>
            </ul>
          </div>
        </div>       
      </div>

      <div class="span6">
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"> <i class="icon-file"></i> </span>
            <h5>Shipping Details</h5>
          </div>
          <div class="widget-content nopadding">
            <ul class="recent-posts">
              <li>
               Name: {{$deliveryAddress->name}} <br>
               Email: {{$deliveryAddress->user_email}} <br>
               Address: {{$deliveryAddress->address}} <br>
               Country: {{$deliveryAddress->country}} <br>
               City: {{$deliveryAddress->city}} <br>
               State: {{$deliveryAddress->state}} <br>
               Mobile: {{$deliveryAddress->mobile}} <br>
               Date: {{$deliveryAddress->created_at}} <br>
              </li>
            </ul>
          </div>
        </div>       
      </div>
    </div>
    <hr>
  </div>
</div>
<!--main-container-part-->

@endsection