<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    public function orders()
    {
    	return $this->hasMany('App\OrderProduct','order_id');
    }
    public function deliveryAddress()
    {
    	return $this->hasMany('App\deliveryAddress','user_id');
    }
}
