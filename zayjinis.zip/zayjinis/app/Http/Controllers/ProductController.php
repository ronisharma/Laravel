<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Auth;
use Session;
use Image;
use App\CategoryModel;
use App\Product;
use App\ProductAttribute;
use App\ProductsImage;
use App\Order;
//use App\OrderProduct;
use App\DeliveryAddress;

class ProductController extends Controller
{
    public function addProduct(Request $request)
    {
    	if($request->isMethod('post'))
    	{
    		$data=$request->all();
    		if(empty($data['product_cat']))
    		{
    			return redirect()->back()->with('flash_message_error','Under Category is Missing');
    		}
    		$products = new Product();
    		$products->product_name=$data['product_name'];
    		if(!empty($data['product_cat'])){
    			$products->category_id=$data['product_cat'];
    		}else{
    			$products->category_id=0;
    		}    		
    		$products->product_code=$data['product_code'];
    		$products->price=$data['product_price'];
    		if(!empty($data['description'])){
    			$products->description=$data['description'];
    		}else{
    			$products->description='';
    		}    
            if(!empty($data['care'])){
                $products->care=$data['care'];
            }else{
                $products->care='';
            }		
    		$products->product_color=$data['product_color'];
    		//===upload image===//;
    		if($request->hasFile('image'))
    		{
    			$image_tmp = Input::file('image');
    			if($image_tmp->isValid()){
    				$extension = $image_tmp->getClientoriginalExtension();
    				$filename = rand(111,9999).'.'.$extension;
    				$large_image_path='public/backend/products/large_image/'.$filename;
    				$medium_image_path='public/backend/products/medium_image/'.$filename;
    				$small_image_path='public/backend/products/small_image/'.$filename;
    				//==resize==//
    				Image::make($image_tmp)->save($large_image_path);
    				Image::make($image_tmp)->resize(300,300)->save($medium_image_path);
    				Image::make($image_tmp)->resize(268,249)->save($small_image_path);

    				$products->image = $filename;
    			}
    		}
    		$products->save();
    		//return redirect()->back()->with('flash_message_success','Product Add Successfully');
    		return redirect('/admin/view-product')->with('flash_message_success','Product Add Successfully');
    	}
    	//==category select==//
    	$categories = CategoryModel::where(['parent_id'=>0])->get();
    	$categories_dropdown = "<option value=''>Select One</option>";
    	foreach ($categories as $value) {
    		$categories_dropdown .= "<option value='".$value->id."'>".$value->name."</option>"; 
    		$sub_category = CategoryModel::where(['parent_id' =>$value->id])->get();

    		foreach ($sub_category as $sub_cat) {
    			$categories_dropdown .="<option value='".$sub_cat->id."'>&nbsp;&nbsp;-->&nbsp;".$sub_cat->name."</option>";
    		}
    	}
    	return view('admin.products.add_product')->with(compact('categories_dropdown'));
    }
    public function viewProduct()
    {
    	$products = Product::get();
    	//$products = json_decode(json_encode($products));
    	foreach ($products as $key => $value) {
    		$category = CategoryModel::where(['id'=>$value->category_id])->first();
    		//print '<pre>';print_r($category);die;
    		$products[$key]->category = $category['name'];
    	}
    	//print '<pre>';print_r($products);die;
    	return view('admin.products.view_product')->with(compact('products','category'));
    }
    public function editProduct(Request $request,$id=null)
    {
    	//==update product==//
    	if($request->isMethod('post'))
    	{
    		$data = $request->all();
    		//===Edit image===//;
    		if($request->hasFile('image'))
    		{
    			$image_tmp = Input::file('image');
    			if($image_tmp->isValid()){
    				$extension = $image_tmp->getClientoriginalExtension();
    				$filename = rand(111,9999).'.'.$extension;
    				$large_image_path='public/backend/products/large_image/'.$filename;
    				$medium_image_path='public/backend/products/medium_image/'.$filename;
    				$small_image_path='public/backend/products/small_image/'.$filename;
    				//==resize==//
    				Image::make($image_tmp)->save($large_image_path);
    				Image::make($image_tmp)->resize(600,600)->save($medium_image_path);
    				Image::make($image_tmp)->resize(300,300)->save($small_image_path);

                    unlink('public/backend/products/large_image/'.$request['current_image']);
                    unlink('public/backend/products/medium_image/'.$request['current_image']);
                    unlink('public/backend/products/small_image/'.$request['current_image']);
    			}
    		}else{
    			$filename = $request['current_image'];
    		}
    		Product::where(['id'=>$id])->update(['category_id'=>$data['product_cat'],
    													'product_name'=>$data['product_name'],
    													'product_code'=>$data['product_code'],
    													'price'=>$data['product_price'],
    													'description'=>$data['description'],
                                                        'care'=>$data['care'],
    													'product_color'=>$data['product_color'],
    													'image'=>$filename
    													]);
    		return redirect()->back()->with('flash_message_success','Product Update Successfully');
    	}
    	//==end update product==//
    	//==Show product Details==//
    	$productDetails = Product::where(['id' => $id])->first();
    	//==category select==//
    	$categories = CategoryModel::where(['parent_id'=>0])->get();
    	$categories_dropdown = "<option value=''>Select One</option>";
    	foreach ($categories as $value) {
    		if($value->id == $productDetails->category_id){
    			$selected = "selected";
    		}
    		else{
    			$selected = "";
    		}
    		$categories_dropdown .= "<option value='".$value->id."' ".$selected.">".$value->name."</option>"; 
    		$sub_category = CategoryModel::where(['parent_id' =>$value->id])->get();

    		foreach ($sub_category as $sub_cat) {
    			if($sub_cat->id == $productDetails->category_id){
	    			$selected = "selected";
	    		}
	    		else{
	    			$selected = "";
	    		}
    			$categories_dropdown .="<option value='".$sub_cat->id."' ".$selected.">&nbsp;&nbsp;-->&nbsp;".$sub_cat->name."</option>";
    		}
    	}
    	return view('admin.products.edit_product')->with(compact('productDetails','categories_dropdown'));
    }
    public function deleteProductimage($id)
    {
        $ImageName = Product::where(['id'=>$id])->first();
        $ImagePath_large = 'public/backend/products/large_image/';
        $ImagePath_medium = 'public/backend/products/medium_image/';
        $ImagePath_small = 'public/backend/products/small_image/';

        if(file_exists($ImagePath_large.$ImageName->image)){
            unlink($ImagePath_large.$ImageName->image);
        }
        if(file_exists($ImagePath_medium.$ImageName->image)){
            unlink($ImagePath_medium.$ImageName->image);
        }
        if(file_exists($ImagePath_small.$ImageName->image)){
            unlink($ImagePath_small.$ImageName->image);
        }

    	Product::where(['id'=>$id])->update(['image'=>'0']);
    	return redirect()->back()->with('flash_message_success','Product Image Deleted');
    }
    public function deleteProduct($id=null)
    {
        $ImageName = Product::where(['id'=>$id])->first();
        $ImagePath_large = 'public/backend/products/large_image/';
        $ImagePath_medium = 'public/backend/products/medium_image/';
        $ImagePath_small = 'public/backend/products/small_image/';

        if(file_exists($ImagePath_large.$ImageName->image)){
            unlink($ImagePath_large.$ImageName->image);
        }
        if(file_exists($ImagePath_medium.$ImageName->image)){
            unlink($ImagePath_medium.$ImageName->image);
        }
        if(file_exists($ImagePath_small.$ImageName->image)){
            unlink($ImagePath_small.$ImageName->image);
        }
        
    	Product::where(['id'=>$id])->delete();
    	return redirect()->back()->with('flash_message_success','Product Deleted Successfully');
    }
    //===product attributes===//
    public function addAttributes(Request $request,$id=null)
    {
    	$productDetails = Product::with('attributes')->where(['id'=>$id])->first();
    	if($request->isMethod('post'))
    	{
    		$data = $request->all();
    		foreach ($data['sku'] as $key => $value) {
    			if(!empty($value)){
                     $countSKU = ProductAttribute::where(['sku'=>$value])->count();
                    if($countSKU>0){
                        return redirect('admin/add-attribute/'.$id)->with('flash_message_error', 'SKU already exists. Please add another SKU.');    
                    }
                    $countSize = ProductAttribute::where(['product_id'=>$id,'size'=>$data['size'][$key]])->count();
                    if($countSize>0){
                        return redirect('admin/add-attribute/'.$id)->with('flash_message_error', 'Attribute already exists. Please add another Attribute.');    
                    }
    				$attributes = new ProductAttribute;
    				$attributes->product_id = $id;
    				$attributes->sku = $value;
    				$attributes->size = $data['size'][$key];
    				$attributes->price = $data['price'][$key];
    				$attributes->stock = $data['stock'][$key];
    				$attributes->save();
    			}
    		}
    		return redirect('/admin/add-attribute/'.$id)->with('flash_message_success','Attribute add Successfully');
    	}
    	
    	return view('admin.products.add_attribute')->with(compact('productDetails'));
    }
    public function editAttributes(Request $request,$id=null)
    {
        if($request->isMethod('post')){
            $data = $request->all();
            foreach($data['idAttr'] as $key=> $attr){
                if(!empty($attr)){
                    ProductAttribute::where(['id' => $data['idAttr'][$key]])->update(['price' => $data['price'][$key], 'stock' => $data['stock'][$key]]);
                }
            }
            return redirect('admin/add-attribute/'.$id)->with('flash_message_success', 'Product Attributes has been updated successfully');
        }
    }
    public function deleteAttribute($id=null)
    {
    	echo $id; die;
    	ProductAttribute::where(['id'=>$id])->delete();
    	return redirect()->back()->with('flash_message_success','Attribute Deleted Successfully');
    }
    public function addImages(Request $request,$id=null)
    {
        if($request->isMethod('post'))
        {
            $data = $request->all();
            if ($request->hasFile('image'))
            {
                $files = $request->file('image');
                foreach($files as $file)
                {
                    // Upload Images after Resize
                    $image = new ProductsImage;
                    $extension = $file->getClientOriginalExtension();
                    $fileName = rand(111,99999).'.'.$extension;
                    $large_image_path = 'public/backend/products/large_image'.'/'.$fileName;
                    $medium_image_path = 'public/backend/products/medium_image'.'/'.$fileName;  
                    $small_image_path = 'public/backend/products/small_image'.'/'.$fileName;  
                    Image::make($file)->save($large_image_path);
                    Image::make($file)->resize(300, 300)->save($medium_image_path);
                    Image::make($file)->resize(268, 280)->save($small_image_path);
                    $image->image = $fileName;  
                    $image->product_id = $data['product_id'];
                    $image->save();
                }   
            }

            return redirect('admin/add-images/'.$id)->with('flash_message_success', 'Product Images has been added successfully');
        }

        $productDetails = Product::where(['id'=>$id])->first();
        $category_name = CategoryModel::where(['id'=>$productDetails->category_id])->first();
        $productImages = ProductsImage::where(['product_id'=>$id])->orderBy('id','desc')->get();
        return view('admin.products.add_images')->with(compact('productDetails','category_name','productImages'));
    }

    //===orders===//
    public function viewOrder()
    {
        $order = Order::with('orders')->get();
        return view('admin.products.order')->with(compact('order'));
    }
    public function orderDetails($id)
    {
        $order = Order::with('orders')->where('id',$id)->first();
        $deliveryAddress = Order::with('deliveryAddress')->where('id',$id)->first();
        return view('admin.products.order_details')->with(compact('order','deliveryAddress'));
    }
}
