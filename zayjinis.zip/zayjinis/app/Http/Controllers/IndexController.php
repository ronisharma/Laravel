<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Slider;
use App\Product;
use App\CategoryModel;
use App\ProductAttribute;
use App\ProductsImage;
use App\Coupon;
use App\Country;
use App\User;
use App\DeliveryAddress;
use App\Order;
use App\OrderProduct;
use Auth;
use DB;
use Session;

class IndexController extends Controller
{
    public function index()
    {
        //===for slider==//
        $slider = Slider::where(['status'=>1])->get();
    	//==for product==//
    	$product = Product::orderBy('id','desc')->get();
    	//$product = Product::inRandomOrder()->get();
        $navbar = true;
    	//==for category==//
    	$categories = CategoryModel::with('categories')->where(['parent_id'=>'0'])->get();
    	return view('index')->with(compact('slider','product','categories','navbar'));
    }
    public function searchProduct(Request $request)
    {
        if($request->isMethod('post'))
        {
            $navbar = '';
            $productName = $request->input('name');
            $productCategory = $request->input('cat_id');
            if($productName !== '' || $productCategory !== '')
            {
                $products = Product::where('product_name', 'LIKE', '%' . $productName . '%')->where('category_id', 'LIKE','%'.$productCategory.'%')->get();

                return view('products.search', compact('products','navbar'));
            }
            return false;
        }
    }
    public function product($url=null)
    {
        $navbar= '';
        //==show 404 error page--//
        $countCategory = CategoryModel::where(['url'=>$url])->count();
        if($countCategory==0){
            abort(404);
        }
        //==category & subcategory view product==//
    	$categoryDetails = CategoryModel::where(['url'=>$url])->first();
        if($categoryDetails->parent_id==0)
        {
            //print $categoryDetails->id;die;
            $subcategories = CategoryModel::where(['id'=>$categoryDetails->id])->get();
            //var_dump($subcategories);die;
            foreach ($subcategories as $subcat) {
                $cat_ids[] = $subcat->id;
                //var_dump($subcat);die;
            }            
            $productsAll = Product::whereIn('category_id',$cat_ids)->get();
            
            //echo "<pre>";print_r($productsAll);die;
        }
        else{
            $productsAll = Product::where(['category_id'=>$categoryDetails->id])->get();
        }
    	//var_dump($categoryDetails->id);die;
    	$categories = CategoryModel::with('categories')->where(['parent_id'=>'0'])->get();
    	return view('products.listing')->with(compact('categoryDetails','productsAll','categories','navbar'));    	
    }
    public function productDetails($id=null)
    {
        $navbar = '';
        //==find total stock==//
        $total_stock = ProductAttribute::where('product_id',$id)->sum('stock');
        //==find alter image==//
        $alterImage = ProductsImage::where(['product_id'=>$id])->get();
        //==find category==//
        $categories = CategoryModel::with('categories')->where(['parent_id'=>'0'])->get();
        //==single product details==//
        $productDetails = Product::with('attributes')->where(['id'=>$id])->first();
        //==Related Product==//
        $relatedProducts = Product::where('id','!=',$id)->where(['category_id' => $productDetails->category_id])->get();
        return view('products.product_details')->with(compact('productDetails','categories','alterImage','total_stock','relatedProducts','navbar'));
    }
    public function getproductPrice(Request $request)
    {
        $data = $request->all();
        print '<pre>';print_r($data);die;
    }
    public function addCart(Request $request)
    {
        $data = $request->all();
        if(empty(Auth::User()->email)){
            $data['user_email'] = '';    
        }else{
            $data['user_email'] = Auth::User()->email;
        }

        $session_id = Session::get('session_id');
        if(!isset($session_id)){
        $session_id = str_random(30);
        Session::put('session_id',$session_id);
        }
        
        //print '<pre>';print_r($data);die;
       
        //==get sku==//
        $getSKU = ProductAttribute::select('sku')->where(['product_id' => $data['product_id']])->first();

         $exiting_product = DB::table('cart')->where(['product_id' => $data['product_id'],'product_name' => $data['product_name'],'product_code' => $getSKU['sku'],'product_color' => $data['product_color'],'session_id' => $session_id])->count();
        //var_dump($exiting_product);die;
        if($exiting_product > 0){
            return redirect()->back()->with('flash_message_success','Product Already Exit');
        }

        DB::table('cart')->insert(['product_id' => $data['product_id'],'product_name' => $data['product_name'],
            'product_code' => $getSKU['sku'],'product_color' => $data['product_color'],
            'price' => $data['price'],'size' => $data['size'],'image'=>$data['image'],'quantity' => $data['quantity'],'user_email' => $data['user_email'],'session_id' => $session_id]);

        return redirect('cart')->with('flash_message_success','Product Add to Cart Successfully');
    }
    public function cart()
    {
        $navbar = '';
        if(Auth::Check()){
            $user_email = Auth::User()->email;
            $userCart = DB::table('cart')->where(['user_email'=>$user_email])->get();
        }else{
            $session_id = Session::get('session_id');
            $userCart = DB::table('cart')->where(['session_id'=>$session_id])->get();
        }
        foreach($userCart as $key => $product){
            $productDetails = Product::where('id',$product->product_id)->first();
            $userCart[$key]->image = $productDetails->image;
        }
        return view('products.cart')->with(compact('userCart','navbar'));
    }
    public static function carts()
    {
        //$user_email = Auth::User()->email;
        $cart = DB::table('cart')->get();
        return $cart;
        
    }
    public function deleteCart($id=null)
    {
        DB::table('cart')->where('id',$id)->delete();
        return redirect('cart')->with('flash_message_success','Product has been deleted from Cart');
    }
    public function updateQuantity($id=null,$quantity=null)
    {
         $getProductSKU = DB::table('cart')->select('product_code','quantity')->where('id',$id)->first();
         //print '<pre>';print_r($getProductSKU);die;
         $getProductStock = ProductAttribute::where('sku',$getProductSKU->product_code)->first();
         //print '<pre>';print_r($getProductStock);die;
         $updated_quantity = $getProductSKU->quantity+$quantity;
         
         if($getProductStock->stock >= $updated_quantity){
            DB::table('cart')->where('id',$id)->increment('quantity',$quantity); 
            return redirect('cart')->with('flash_message_success','Product Quantity has been updated in Cart!');
         }
         else{
            return redirect('cart')->with('flash_message_error','Required Product Quantity is not available!');
         }
            
    }
    public function applyCoupon(Request $request)
    {
        Session::forget('couponAmount');
        Session::forget('couponCode');

        if($request->isMethod('post'))
        {
            $data = $request->all();
            $couponCount = Coupon::where('coupon_code',$data['coupon_code'])->count();
            if($couponCount == 0){
                return redirect()->back()->with('flash_message_success','Coupon does not Exit');
            }
            else{
                $couponDetails = Coupon::where('coupon_code',$data['coupon_code'])->first();
                //==check active inactive==//
                if($couponDetails->status==0){
                    return redirect()->back()->with('flash_message_success','Coupon Number is InActive');
                }
                //==check expire date==//
                $expire_date = $couponDetails->expiry_date;
                $current_date = date('yy-mm-dd');

                if($expire_date < $current_date){
                    return redirect()->back()->with('flash_message_success','Coupon Number is Expired');
                }
                //==total amount==//
                //$session_id = Session::get('session_id');
                //$cart = DB::table('cart')->where('session_id',$session_id)->get();
                if(Auth::Check()){
                    $user_email = Auth::User()->email;
                    $cart = DB::table('cart')->where(['user_email'=>$user_email])->get();
                }else{
                    $session_id = Session::get('session_id');
                    $cart = DB::table('cart')->where(['session_id'=>$session_id])->get();
                }
                $total_amount = 0;
                foreach ($cart as $amount) {
                    $total_amount = $total_amount + ($amount->price * $amount->quantity);
                }
                //==coupon amount by fixed and percentage==//
                if($couponDetails->amount_type=='Fixed')
                {
                   $couponAmount = $couponDetails->amount;
                }
                else{
                    $couponAmount = $total_amount * ($couponDetails->amount/100);die;
                }

                Session::put('couponAmount',$couponAmount);
                Session::put('couponCode',$data['coupon_code']);
                return redirect()->back()->with('flash_message_success','Coupon Code Successfully Applied, You are Availing Discount');

            }
        }
    }//==end apply==//
    public function checkout(Request $request)
    {
        $navbar = '';
        $user_id = Auth::User()->id;
        $user_email = Auth::User()->email;
        $userDetails = User::find($user_id);
        $countries = Country::get();
        //== check if shipping address exits==//
        $shippingCount = DeliveryAddress::where('user_id',$user_id)->count();
        $shippingDetails = array();
        if($shippingCount>0)
        {
            $shippingDetails = DeliveryAddress::where('user_id',$user_id)->first();
            //print '<pre>'; print_r($shippingDetails); die;
        }
        //==update user_email in cart table==// 
         $session_id = Session::get('session_id');
         $cart = DB::table('cart')->where('session_id',$session_id)->update(['user_email'=>$user_email]);
        //==start if==//
        if($request->isMethod('post'))
        {
            $data = $request->all();
            if( empty($data['billing_name']) || 
                empty($data['billing_address']) ||
                empty($data['billing_country']) ||
                empty($data['billing_city']) ||
                empty($data['billing_state']) ||
                empty($data['billing_pincode']) ||
                empty($data['billing_mobile']) ||
                empty($data['shipping_name']) ||
                empty($data['shipping_address']) ||
                empty($data['shipping_country']) ||
                empty($data['shipping_city']) ||
                empty($data['shipping_state']) ||
                empty($data['shipping_pincode']) ||
                empty($data['shipping_mobile'])
              ){
                return redirect()->back()->with('flash_message_error','Please Fill all Field to Checkout');
            }
            User::where('id',$user_id)->update(
                ['name'=>$data['billing_name'],'address'=>$data['billing_address'],'country'=>$data['billing_country'],'city'=>$data['billing_city'],'state'=>$data['billing_state'],'pincode'=>$data['billing_pincode'],'mobile'=>$data['billing_mobile']]
                );
            //==shipping details==//
            if($shippingCount>0)
            {
                //==update shipping Details==//
                DeliveryAddress::where('user_id',$user_id)->update(
                ['name'=>$data['shipping_name'],'address'=>$data['shipping_address'],'country'=>$data['shipping_country'],'city'=>$data['shipping_city'],'state'=>$data['shipping_state'],'pincode'=>$data['shipping_pincode'],'mobile'=>$data['shipping_mobile']]
                );
            }
            else{
                //==insert new shipping address==//
                $shippingInsert = new DeliveryAddress;
                $shippingInsert->user_id = $user_id;
                $shippingInsert->user_email = $user_email;
                $shippingInsert->name = $data['shipping_name'];
                $shippingInsert->address = $data['shipping_address'];
                $shippingInsert->country = $data['shipping_country'];
                $shippingInsert->city = $data['shipping_city'];
                $shippingInsert->state = $data['shipping_state'];
                $shippingInsert->pincode = $data['shipping_pincode'];
                $shippingInsert->mobile = $data['shipping_mobile'];
                $shippingInsert->save();
            }
            return redirect()->action('IndexController@orderReview')->with('flash_message_success','Shipping Address Successfully Save');
        }//==end if==//
        return view('products.checkout')->with(compact('countries','userDetails','shippingDetails','navbar'));
    }
    public function orderReview()
    {
        $navbar = '';
        $user_id = Auth::User()->id;
        $user_email = Auth::User()->email;
        $userDetails = User::where('id',$user_id)->first();
        $shippingDetails = DeliveryAddress::where('user_id',$user_id)->first();

        $userCart = DB::table('cart')->where('user_email',$user_email)->get();
         foreach($userCart as $key => $product){
            $productDetails = Product::where('id',$product->product_id)->first();
            $userCart[$key]->image = $productDetails->image;
        }

        return view('products.order_review')->with(compact('userDetails','shippingDetails','userCart','navbar'));
    }
    public function placeOrder(Request $request)
    {
        $navbar = '';
        if($request->isMethod('post')){
            $data = $request->all();
            $user_id = Auth::User()->id;
            $user_email = Auth::User()->email;

            if(empty(Session::get('couponAmount'))){
                $coupon_amount = '';
            }else{
                $coupon_amount = Session::get('couponAmount');
            }

            if(empty(Session::get('couponCode'))){
                $coupon_code = '';
            }else{
                $coupon_code = Session::get('couponCode');
            }

            $shippingDetails = DeliveryAddress::where(['user_email'=>$user_email])->first();
            //print '<pre>';print_r($shippingDetails);die;
            //==insert order details==//
            $order = new Order;
            $order->user_id = $user_id;
            $order->user_email = $user_email;
            $order->name = $shippingDetails->name;
            $order->address = $shippingDetails->address;
            $order->country = $shippingDetails->country;
            $order->city = $shippingDetails->city;
            $order->state = $shippingDetails->state;
            $order->pincode = $shippingDetails->pincode;
            $order->mobile = $shippingDetails->mobile;
            $order->shipping_charges = 0;
            $order->coupon_code = $coupon_code;
            $order->coupon_amount = $coupon_amount;
            $order->order_status = 'new';
            $order->payment_method = $data['payment'];
            $order->grand_total = $data['grand_total'];
            $order->save();

            $order_id = DB::getPdo()->lastInsertId();
            //==insert order product details==//
            $cartProducts = DB::table('cart')->where(['user_email'=>$user_email])->get();
            foreach ($cartProducts as $pro) {
                $orderProduct = new orderProduct;
                $orderProduct->order_id = $order_id;
                $orderProduct->user_id = $user_id;
                $orderProduct->product_id = $pro->product_id;
                $orderProduct->product_code = $pro->product_code;
                $orderProduct->product_name = $pro->product_name;
                $orderProduct->product_color = $pro->product_color;
                $orderProduct->product_size = $pro->size;
                $orderProduct->product_price = $pro->price;
                $orderProduct->product_qty = $pro->quantity;
                $orderProduct->save();
            }
            Session::put('order_id',$order_id);
            Session::put('grand_total',$data['grand_total']);
            return redirect('/thanks')->with(compact('navbar'));
        }
    }
    public function thanks()
    {
        $navbar = '';
        $user_email = Auth::User()->email;
        DB::table('cart')->where(['user_email'=>$user_email])->delete();
        return view('products.thanks')->with(compact('navbar'));
    }
}
