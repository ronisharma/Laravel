<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\CategoryModel;

class CategoryController extends Controller
{
    public function addCategory(Request $request)
    {
    	if($request->isMethod('post'))
    	{
    		$data=$request->all();
    		//print '<pre>';print_r($data);die;
            if(empty($data['status'])){
                $status=0;
            }else{
                $status=1;
            }
    		$category = new CategoryModel();
    		$category->name = $data['name'];
    		$category->parent_id = $data['category_lebel'];
    		$category->description = $data['description'];
    		$category->url = $data['url'];
            $category->status = $status;
    		$category->save();
    		return redirect('/admin/add-category')->with('flash_message_success','Category added Successfuly');
    	}
    	$lebels=CategoryModel::where(['parent_id'=>0])->get();
    	return view('admin.categories.add_category')->with(compact('lebels'));
    }
    public function viewCategory()
    {
    	$categories = CategoryModel::get();
    	$categories = json_decode(json_encode($categories)); // if data not found then use it.
    	return view('admin.categories.view_category')->with(compact('categories'));
    }
    public function editCategory(Request $request,$id=null)
    {
    	if($request->isMethod('post'))
    	{
    		$data=$request->all();
            if(empty($data['status'])){
                $status=0;
            }else{
                $status=1;
            }
    		CategoryModel::where(['id' => $id])->update(['name'=>$data['name'],'parent_id'=>$data['category_lebel'],'description'=>$data['description'],'url'=>$data['url'],'status'=>$status]);
    		return redirect('/admin/view-category')->with('flash_message_success','Update Successfuly');
    	}
    	$categoryId = CategoryModel::where(['id' => $id])->first();
    	$lebels=CategoryModel::where(['parent_id'=>0])->get();
    	return view('admin.categories.edit_category')->with(compact('categoryId','lebels'));
    }
    public function deleteCategory($id=null)
    {
    	if(!empty($id))
    	{
    		CategoryModel::where(['id'=>$id])->delete();
    		return redirect('/admin/view-category')->with('flash_message_success','Category deleted Successfuly');
    	}
    }
}
