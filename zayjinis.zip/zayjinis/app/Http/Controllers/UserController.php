<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Hash;
use App\User;
use App\Order;
use Auth;
use Session;
use App\Country;
use DB;

class UserController extends Controller
{
	public function loginRegister()
	{
        $navbar = '';
		return view('users.login_register')->with(compact('navbar'));
	}
    public function register(Request $request)
    {
        $navbar = '';
    	if($request->isMethod('post'))
    	{
    		$data = $request->all();
    		$exitUser = User::where('email',$data['email'])->count();
    		if($exitUser>0)
    		{
    			return redirect()->back()->with('flash_message_error','This Email already Use');
    		}
    		else{
    			$user = new User;
    			$user->name = $data['name'];
    			$user->email = $data['email'];
    			$user->password = bcrypt($data['password']);
    			$user->admin = 0;
    			$user->save();
    			if(Auth::attempt(['email'=>$data['email'],'password'=>$data['password']]))
    			{
    				Session::put('fontSession',$data['email']);

                    if(Auth::Check()){
                        $user_email = Auth::User()->email;
                        $session_id = Session::get('session_id');
                        $userCart = DB::table('cart')->where('session_id',$session_id)->update(['user_email'=>$user_email]);
                    }
    				return redirect('/cart')->with(compact('navbar'));
    			}
    		}
    		
    	}
    	return view('users.login_register');
    }
    public function login(Request $request)
    {
    	if($request->isMethod('post'))
    	{
    		$data = $request->all();
    		if(Auth::attempt(['email'=>$data['email'],'password'=>$data['password']])){
    			Session::put('fontSession',$data['email']);
    			return redirect('/checkout');
    		}
    		else{
    			return redirect()->back()->with('flash_message_error','Invalid Email or Password');
    		}
    	}
    }
    public function account(Request $request)
    {
        $navbar = '';
        $user_id = Auth::user()->id;
        //$userDetails = User::where(['id'=>$user_id])->first();
        $userDetails = User::find($user_id);
        //print '<pre>'; print_r($userDetails);die;
        $countries = Country::get();
        //==update user==//
        if($request->isMethod('post')){
            $data = $request->all();
            if(empty($data['name'])){
                return redirect()->back()->with('flash_message_error','Name is Required');
            }
            if(empty($data['address'])){
                $data['address']='';
            }
            if(empty($data['mobile'])){
                $data['mobile']='';
            }
            $user = User::find($user_id);
            $user->name = $data['name'];
            $user->address = $data['address'];
            $user->city = $data['city'];
            $user->country = $data['country'];
            $user->state = $data['state'];
            $user->pincode = $data['pincode'];
            $user->mobile = $data['mobile'];
            $user->save();
            return redirect()->back()->with('flash_message_success','User Update Successfully');
        }

    	return view('users.account')->with(compact('countries','userDetails','navbar'));
    }
    public function userpwdCheck(Request $request)
    {
        $data = $request->all();
        $current_pwd = $data['current_pwd'];
        $user_id = Auth::User()->id;
        $old_pwd =  User::find($user_id)->first();
        if(Hash::check($current_pwd,$old_pwd->password)){
            echo "true"; die;
        }else{
            echo "false"; die;
        }
    }
    public function updateUserpwd(Request $request)
    {
        if($request->isMethod('post'))
        {
            $data = $request->all();
            $current_pwd = $data['current_pwd'];
            $old_pwd = User::where('id',Auth::User()->id)->first();
            if(Hash::check($current_pwd,$old_pwd->password)){
                $new_pwd = bcrypt($data['new_pwd']);
                User::where('id',$old_pwd->id)->update(['password'=>$new_pwd]);
                return redirect('/account')->with('flash_message_success','Password update Successfully');
            }else{
                return redirect()->back()->with('flash_message_error','current Password is Incorrect');
            }

        }
    }
    public function checkEmail(Request $request)
    {
    	$data = $request->all();
    	$exitUser = User::where(['email'=>$data['email']])->count();
    	if($exitUser > 0){
    		echo "false";
    	}
    	else{
    		echo "true";die;
    	}
    }
    public function userOrder()
    {
        $navbar = '';
        $user_id = Auth::User()->id;
        $orderDetails = Order::with('orders')->where('user_id',$user_id)->orderBy('id','DESC')->get();
        $orderDetails = json_decode(json_encode($orderDetails));
        return view('orders.order')->with(compact('orderDetails','navbar'));
    }
    public function userOrderDetails($order_id)
    {
        $navbar = '';
        $orderDetails = Order::with('orders')->where('id',$order_id)->first();
        //$orderDetails = json_decode(json_encode($orderDetails));
        return view('orders.orderDetails')->with(compact('orderDetails','navbar'));
    }
    public function userLogout()
    {
    	Auth::logout();
    	Session::forget('fontSession');
    	return redirect('/');
    }
}
