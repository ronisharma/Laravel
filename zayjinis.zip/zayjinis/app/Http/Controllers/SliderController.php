<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use App\Slider;
use Image;

class SliderController extends Controller
{
    public function addSlider(Request $request)
    {
    	if($request->isMethod('post'))
    	{
    		$data = $request->all();
    		if(empty($data['status'])){
    			$status=0;
    		}else{
    			$status=1;
    		}
    		if(empty($data['link'])){
    			$data['link']='';
    		}

    		$slider = new Slider();
    		$slider->name = $data['name'];
    		$slider->link = $data['link'];
    		$slider->status = $status;
    		//===upload image===//;
    		if($request->hasFile('image'))
    		{
    			$image_tmp = Input::file('image');
    			if($image_tmp->isValid()){
    				$extension = $image_tmp->getClientoriginalExtension();
    				$filename = rand(111,9999).'.'.$extension;
    				$large_image_path='public/backend/sliders/'.$filename;
    				//==resize==//
    				Image::make($image_tmp)->save($large_image_path);

    				$slider->image = $filename;
    			}
    		}//end image
    		$slider->save();
    		return redirect('/admin/add-slider')->with('flash_message_success','Slider Add Successfully');
    	}
    	return view('admin.sliders.add_slider');
    }
    public function viewSlider()
    {
    	$slider = Slider::get();
    	return view('admin.sliders.view_slider')->with(compact('slider'));
    }
    public function editSlider(Request $request,$id=null)
    {
    	if($request->isMethod('post'))
    	{
    		$data = $request->all();
    		if(empty($data['status']))
    		{
    			$data['status'] = 0;
    		}
    		if(empty($data['link'])){
    			$data['link']='';
    		}
    		//===Edit image===//;
    		if($request->hasFile('image'))
    		{
    			$image_tmp = Input::file('image');
    			if($image_tmp->isValid()){
    				$extension = $image_tmp->getClientoriginalExtension();
    				$filename = rand(111,9999).'.'.$extension;
    				$large_image_path='public/backend/sliders/'.$filename;
    				
    				Image::make($image_tmp)->save($large_image_path);
    				unlink('public/backend/sliders/'.$request['image2']);
    			}
    		}else{
    			$filename = $request['image2'];
    		}
    		Slider::where('id',$id)->update(['name'=>$data['name'],'link'=>$data['link'],'image'=>$filename,'status'=>$data['status']]);
    		return redirect('admin/edit-slider/'.$id)->with('flash_message_success','Edit update Successfully');
    	}
    	$sliderDetails = Slider::find($id);
    	return view('admin.sliders.edit_slider')->with(compact('sliderDetails'));
    }
    public function deleteSlider($id=null)
   {
   		$slider = Slider::find($id);
   		//echo $slider->image;die;
   		unlink('public/backend/sliders/'.$slider->image);
   		Slider::find($id)->delete();
   		return redirect()->back()->with('flash_message_success','Slider Delete Successfully');
   }
}
