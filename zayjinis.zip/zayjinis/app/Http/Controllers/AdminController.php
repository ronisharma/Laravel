<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Illuminate\Support\Facades\Redirect;
use Session;
use App\User;
use Illuminate\Support\Facades\Hash;

class AdminController extends Controller
{
    public function login(Request $request)
    {
    	if($request->isMethod('post'))
    	{
    		$data=$request->input();
    		if(Auth::attempt(['email'=>$data['email'],'password'=>$data['password'],'admin'=>'1']))
    		{
    			Session::put('adminsession',$data['email']);
    			//return redirect('admin/dashboard');
    			return redirect::action('AdminController@dashboard');
    		}
    		else
    		{
    			return redirect('/admin')->with('flash_message_error','Invalid Email or Password');
    		}
    	}
    	return view('admin.admin_login');
    }
    public function dashboard()
    {
    	/*===Session system===
    	if(Session::has('adminsession'))
    	{

    	}
    	else{
    		return redirect('/admin')->with('flash_message_error','Please Login to Access !');
    	}
    	*/
    	//==another Middleware system==//
    	return view('admin.dashboard');
    }
    public function setting()
    {
    	return view('admin.setting');
    }
    public function chkpassword(Request $request)
    {
    	$data = $request->all();
    	$current_password = $data['current_pwd'];
    	$check_pwd = User::where(['admin' => '1'])->first();
    	if(Hash::check($current_password,$check_pwd->password))
    	{
    		echo "true"; die;
    	}
    	else{
    		echo "false"; die;
    	}
    }
    public function updatePassword(Request $request)
    {
        if($request->isMethod('post'))
        {
            $data=$request->all();
            // print '<pre>';
            // print_r($data); die;
            $current_password=$data['current_pwd'];
            $check_pwd = User::where(['email' => Auth::User()->email])->first();
            if(Hash::check($current_password,$check_pwd->password))
            {
                $password = bcrypt($data['new_pwd']);
                User::where('id','1')->update(['password' => $password]);
                return redirect('/admin/setting')->with('flash_message_success','Update Successfully');
            }
            else{
                return redirect('/admin/setting')->with('flash_message_error','Current password Incorrect');
            }
        }
    }
    public function logout()
    {
    	session::flush();
    	return redirect('/admin')->with('flash_message_success','Successfully Logout');
    }
}
