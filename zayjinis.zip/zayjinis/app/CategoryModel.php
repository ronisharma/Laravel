<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CategoryModel extends Model
{
    protected $table = 'categories';
    public function categories()
    {
    	return $this->hasMany('App\CategoryModel','parent_id');
    }
}
