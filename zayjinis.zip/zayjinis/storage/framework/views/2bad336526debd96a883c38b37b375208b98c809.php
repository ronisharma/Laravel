<?php $__env->startSection('content'); ?>
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css">
	<section id="cart_items">
		<div class="container">
			<div class="breadcrumbs">
				<ol class="breadcrumb">
				  <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
				  <li class="active"><a href="<?php echo e(url('/user-order')); ?>">Order</a></li>
                  <li><?php echo e($orderDetails->id); ?></li>
				</ol>
			</div>
		</div>
	</section> <!--/#cart_items-->
	<section id="do_action">
		<div class="container">
			<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Product Name</th>
                <th>Product Code</th>
                <th>Product Size</th>
                <th>Product Color</th>
                <th>Product Price</th>
                <th>Product Qty</th>
            </tr>
        </thead>
        <tbody>
        	<?php $__currentLoopData = $orderDetails->orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($value->product_name); ?></td>
                <td><?php echo e($value->product_code); ?></td>
                <td><?php echo e($value->product_size); ?></td>
                <td><?php echo e($value->product_color); ?></td>
                <td><?php echo e($value->product_price); ?></td>
                <td><?php echo e($value->product_qty); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
       
    </table>
		</div>
	</section><!--/#do_action-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fontendLayout.fontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>