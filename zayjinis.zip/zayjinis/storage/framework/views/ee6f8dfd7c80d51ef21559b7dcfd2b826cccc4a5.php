<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Welcome to Zayjinis online Shopping</title>
    <!-- Google font -->
    <link href="https://fonts.googleapis.com/css?family=Hind:400,700" rel="stylesheet">
    <!-- Bootstrap -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('public/fontend/css/bootstrap.min.css')); ?>" />
    <!-- Slick -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('public/fontend/css/slick.css')); ?>" />
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('public/fontend/css/slick-theme.css')); ?>" />
    <!-- nouislider -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('public/fontend/css/nouislider.min.css')); ?>" />
    <!-- Font Awesome Icon -->
    <link rel="stylesheet" href="<?php echo e(asset('public/fontend/css/font-awesome.min.css')); ?>">
    <!-- Custom stlylesheet -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('public/fontend/css/style.css')); ?>" />

    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('public/fontend/css/custom.css')); ?>" />

    <script src="http://code.jquery.com/jquery-1.10.2.js"></script>
    <script src="http://code.jquery.com/ui/1.11.2/jquery-ui.js"></script>

    <script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>

</head>

<body>
    <?php echo $__env->make('layouts.fontendLayout.fontend_header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('layouts.fontendLayout.fontend_footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- jQuery Plugins -->
    <script src="<?php echo e(asset('public/fontend/js/jquery.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('public/fontend/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/fontend/js/slick.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/fontend/js/nouislider.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/fontend/js/jquery.zoom.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/fontend/js/jquery.validate.js')); ?>"></script>
    <script src="<?php echo e(asset('public/fontend/js/main.js')); ?>"></script>


    

</body>

</html>
