<?php $__env->startSection('content'); ?>
<div id="content">
  <div id="content-header">
    <div id="breadcrumb"> <a href="<?php echo e(url('/admin/dashboard')); ?>" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#">Product</a> <a href="#" class="current">add attribute</a> </div>
    <h1>Product Attribute</h1>
  </div>
  <div class="container-fluid"><hr>
    <div class="row-fluid">
      <div class="span12">
      	<?php if(Session::has('flash_message_success')): ?>
			<div class="alert alert-success alert-block">
			    <button type="button" class="close" data-dismiss="alert">×</button> 
			        <strong><?php echo session('flash_message_success'); ?></strong>
			</div>
		  <?php endif; ?>
      <?php if(Session::has('flash_message_error')): ?>
      <div class="alert alert-success alert-block">
          <button type="button" class="close" data-dismiss="alert">×</button> 
              <strong><?php echo session('flash_message_error'); ?></strong>
      </div>
      <?php endif; ?>
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"> <i class="icon-info-sign"></i> </span>
            <h5>Add Attribute</h5>
          </div>
          
          <div class="widget-content nopadding">
            <form enctype="multipart/form-data" class="form-horizontal" method="post" action="<?php echo e(url('/admin/add-attribute/'.$productDetails->id)); ?>" name="add_product" id="add_product" novalidate="novalidate"><?php echo e(csrf_field()); ?>


              <div class="control-group">
                <label class="control-label">Product Name</label>
                <label class="control-label"><strong><?php echo e($productDetails->product_name); ?></strong></label> 
              </div>   
              <div class="control-group">
                <label class="control-label">Product Code</label>
                <label class="control-label"><strong><?php echo e($productDetails->product_code); ?></strong></label>          
              </div>          
              <div class="control-group">
                <label class="control-label">Product Color</label>
                <label class="control-label"><strong><?php echo e($productDetails->product_color); ?></strong></label>           
              </div>
              <div class="form-control">
                <div class="field_wrapper">
                  <div>
                      <input type="text" name="sku[]" id="sku" placeholder="Sku" required="" style="width: 120px;" />
                      <input type="text" name="size[]" id="size" placeholder="Size" required="" style="width: 120px;"/>
                      <input type="text" name="price[]" id="price" placeholder="Price" required="" style="width: 120px;"/>
                      <input type="text" name="stock[]" id="stock" placeholder="Stock" required="" style="width: 120px;"/>
                      <a href="javascript:void(0);" class="add_button" title="Add field">Add</a>
                  </div>
                </div>
              </div>             
              <div class="form-actions">
                <input type="submit" value="Add Attribute" class="btn btn-success">
              </div>
            </form>
          </div>
        </div>

      </div>
      <!--view attribute-->
      <div class="span12">
        <div class="widget-box">
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
            <h5>View Attributes</h5>
          </div>
          <div class="widget-content nopadding">
           <form action="<?php echo e(url('admin/edit-attribute/'.$productDetails->id)); ?>" method="post">
           <?php echo e(csrf_field()); ?>

            <table class="table table-bordered data-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Product Id</th>
                  <th>Sku</th>
                  <th>Size</th>
                  <th>Price</th>
                  <th>Stock</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
              <?php $__currentLoopData = $productDetails['attributes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="gradeX">
                    <td class="center"><input type="hidden" name="idAttr[]" value="<?php echo e($value->id); ?>"><?php echo e($value->id); ?></td>
                    <td><?php echo e($value->product_id); ?></td>
                    <td class="center"><?php echo e($value->sku); ?></td>
                    <td class="center"><?php echo e($value->size); ?></td>
                    <td class="center"><input name="price[]" type="text" value="<?php echo e($value->price); ?>" /></td>
                    <td class="center"><input name="stock[]" type="text" value="<?php echo e($value->stock); ?>" required /></td>
                    <td class="center">
                      <input type="submit" value="Update" class="btn btn-primary btn-mini" />
                      <a rel="<?php echo e($value->id); ?>" rel1="delete-attribute" href="javascript:" class="btn btn-danger btn-mini deleteRecord">Delete</a>
                    </td>

                  </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
             </form>
          </div>
        </div>
      </div>
    </div><!--end view attribute-->
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>