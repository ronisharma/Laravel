<?php $__env->startSection('content'); ?>
<!--main-container-part-->
<div id="content">
  <div id="content-header">
    <div id="breadcrumb"> <a href="<?php echo e(url('/admin/dashboard')); ?>" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#" class="current">Order Details</a> </div>
    <h1>Order Id : #<?php echo e($order->id); ?></h1>
  </div>
  <div class="container-fluid">
    <div class="row-fluid">
      <div class="span6">
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"><i class="icon-time"></i></span>
            <h5>Order Details</h5>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-striped table-bordered">
              <tbody>
                <tr>
                  <td class="taskDesc">Order Date</td>
                  <td class="taskStatus"><span class="in-progress"><?php echo e($order->created_at); ?></span></td>
                </tr>
                <tr>
                  <td class="taskDesc">Order Status</td>
                  <td class="taskStatus"><span class="in-progress"><?php echo e($order->order_status); ?></span></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="span6">
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"><i class="icon-time"></i></span>
            <h5>Customer Details</h5>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-striped table-bordered">
              <tbody>
                <tr>
                  <td class="taskDesc">Customer Name</td>
                  <td class="taskStatus"><span class="in-progress"><?php echo e($order->name); ?></span></td>
                </tr>
                 <tr>
                  <td class="taskDesc">Customer Email</td>
                  <td class="taskStatus"><span class="in-progress"><?php echo e($order->user_email); ?></span></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <div class="row-fluid">
      <div class="span6">
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"> <i class="icon-file"></i> </span>
            <h5>Billing Details</h5>
          </div>
          <div class="widget-content nopadding">
            <ul class="recent-posts">
              <li>
               Name: <?php echo e($order->name); ?> <br>
               Email: <?php echo e($order->user_email); ?> <br>
               Address: <?php echo e($order->address); ?> <br>
               Country: <?php echo e($order->country); ?> <br>
               City: <?php echo e($order->city); ?> <br>
               State: <?php echo e($order->state); ?> <br>
               Mobile: <?php echo e($order->mobile); ?> <br>
               Date: <?php echo e($order->created_at); ?> <br>
              </li>
            </ul>
          </div>
        </div>       
      </div>

      <div class="span6">
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"> <i class="icon-file"></i> </span>
            <h5>Shipping Details</h5>
          </div>
          <div class="widget-content nopadding">
            <ul class="recent-posts">
              <li>
               Name: <?php echo e($deliveryAddress->name); ?> <br>
               Email: <?php echo e($deliveryAddress->user_email); ?> <br>
               Address: <?php echo e($deliveryAddress->address); ?> <br>
               Country: <?php echo e($deliveryAddress->country); ?> <br>
               City: <?php echo e($deliveryAddress->city); ?> <br>
               State: <?php echo e($deliveryAddress->state); ?> <br>
               Mobile: <?php echo e($deliveryAddress->mobile); ?> <br>
               Date: <?php echo e($deliveryAddress->created_at); ?> <br>
              </li>
            </ul>
          </div>
        </div>       
      </div>
    </div>
    <hr>
  </div>
</div>
<!--main-container-part-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>