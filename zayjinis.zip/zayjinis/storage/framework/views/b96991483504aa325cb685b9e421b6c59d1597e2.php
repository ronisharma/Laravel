<div class="left-sidebar">
						<h2>Category</h2>
						<div class="panel-group category-products" id="accordian"><!--category-productsr-->
							<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="panel panel-default">
								<?php if($category->status==1): ?>
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#<?php echo e($category->id); ?>">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											<?php echo e($category->name); ?>

										</a>
									</h4>
								</div>
								<?php endif; ?>
								<div id="<?php echo e($category->id); ?>" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											<?php $__currentLoopData = $category->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if($subcategory->status==1): ?>
											<li><a href="<?php echo e(url('/product/'.$subcategory->url)); ?>"><?php echo e($subcategory->name); ?></a></li>
											<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</ul>
									</div>
								</div>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
						</div><!--/category-products-->
						
						<div class="shipping text-center"><!--shipping-->
							<img src="<?php echo e(asset('public/fontend/images/home/shipping.jpg')); ?>" alt="" />
						</div><!--/shipping-->
					
					</div>