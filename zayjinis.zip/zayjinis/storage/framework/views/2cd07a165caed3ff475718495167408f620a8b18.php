<?php $__env->startSection('content'); ?>
	
	<section id="form" style="margin-top: 10px;"><!--form-->
		<div class="container">
			<?php if(Session::has('flash_message_success')): ?>
            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button> 
                    <strong><?php echo session('flash_message_success'); ?></strong>
            </div>
       		<?php endif; ?>
			<?php if(Session::has('flash_message_error')): ?>
            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button> 
                    <strong><?php echo session('flash_message_error'); ?></strong>
            </div>
       		<?php endif; ?>
		<form action="<?php echo e(url('/checkout')); ?>" method="post" id="checkoutform" name="checkoutform"><?php echo e(csrf_field()); ?>

			<div class="row">
				<div class="col-sm-4 col-sm-offset-1">
					<div class="login-form"><!--login form-->
						<h3>Billing TO</h3>		
						<div class="form-group">				
							<input type="text" name="billing_name" <?php if(!empty($userDetails->name)): ?> value="<?php echo e($userDetails->name); ?>" <?php endif; ?> id="billing_name" class="form-control" placeholder="Enter Name" />
						</div>
						<div class="form-group">
							<input type="text" name="billing_address" <?php if(!empty($userDetails->address)): ?> value="<?php echo e($userDetails->address); ?>" <?php endif; ?> id="billing_address" class="form-control" placeholder="Enter Address" />
						</div>
						<div class="form-group">
							<select name="billing_country" id="billing_country" class="form-control">
								<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($country->country_name); ?>" <?php if(!empty($userDetails->country) && $country->country_name == $userDetails->country): ?> selected <?php endif; ?>><?php echo e($country->country_name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
						<div class="form-group">
							<input type="text" name="billing_city" <?php if(!empty($userDetails->city)): ?> value="<?php echo e($userDetails->city); ?>" <?php endif; ?> id="billing_city" class="form-control" placeholder="Enter City" />
						</div>
						<div class="form-group">
							<input type="text" name="billing_state" <?php if(!empty($userDetails->state)): ?> value="<?php echo e($userDetails->state); ?>" <?php endif; ?> id="billing_state" class="form-control" placeholder="Enter State" />
						</div>
						
						<div class="form-group">
							<input type="text" name="billing_pincode" <?php if(!empty($userDetails->pincode)): ?> value="<?php echo e($userDetails->pincode); ?>" <?php endif; ?> id="billing_pincode" class="form-control" placeholder="Enter Pincode" />
						</div>
						<div class="form-group">
							<input type="text" name="billing_mobile" <?php if(!empty($userDetails->mobile)): ?> value="<?php echo e($userDetails->mobile); ?>" <?php endif; ?> id="billing_mobile" class="form-control" placeholder="Enter Mobile" />
						</div>
						<input type="checkbox" name="billtoship" id="billtoship" value="1">&nbsp;<b>Shipping Address same as Billing Address</b>
					</div>
				</div>
				<div class="col-sm-1">
					<h3 class="or">OR</h3>
				</div>
				<div class="col-sm-4">
					<div class="signup-form"><!--sign up form-->
						<h3>Shipping TO</h3>						
							<div class="form-group">				
							<input type="text" name="shipping_name" id="shipping_name" class="form-control" placeholder="Enter Name" <?php if(!empty($shippingDetails->name)): ?>value="<?php echo e($shippingDetails->name); ?>" <?php endif; ?>  />
						</div>
						<div class="form-group">
							<input type="text" name="shipping_address" id="shipping_address" class="form-control" placeholder="Enter Address" <?php if(!empty($shippingDetails->address)): ?>value="<?php echo e($shippingDetails->address); ?>" <?php endif; ?>/>	
						</div>
						<div class="form-group">
							<select name="shipping_country" id="shipping_country" class="form-control">
								<option value="">Select one</option>
								<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($country->country_name); ?>" <?php if(!empty($shippingDetails->country) && $shippingDetails->country==$country->country_name): ?> selected <?php endif; ?>><?php echo e($country->country_name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
						<div class="form-group">
							<input type="text" name="shipping_city" id="shipping_city" class="form-control" placeholder="Enter City" <?php if(!empty($shippingDetails->city)): ?>value="<?php echo e($shippingDetails->city); ?>" <?php endif; ?>/>
						</div>
						<div class="form-group">
							<input type="text" name="shipping_state" id="shipping_state" class="form-control" placeholder="Enter State" <?php if(!empty($shippingDetails->state)): ?>value="<?php echo e($shippingDetails->state); ?>" <?php endif; ?>/>
						</div>
						<div class="form-group">
							<input type="text" name="shipping_pincode" id="shipping_pincode" class="form-control" placeholder="Enter Pincode" <?php if(!empty($shippingDetails->pincode)): ?>value="<?php echo e($shippingDetails->pincode); ?>" <?php endif; ?>/>
						</div>
						<div class="form-group">
							<input type="text" name="shipping_mobile" id="shipping_mobile" class="form-control" placeholder="Enter Mobile" <?php if(!empty($shippingDetails->mobile)): ?>value="<?php echo e($shippingDetails->mobile); ?>" <?php endif; ?>/>
						</div>	
						<button class="btn btn-success">Checkout</button>		
					</div>
				</div>
			</div>
			</form>
		</div>
	</section><!--/form-->

<?php $__env->stopSection(); ?>
	
	
<?php echo $__env->make('layouts.fontendLayout.fontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>