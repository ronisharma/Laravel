<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Home | RsBazar</title>
    <link href="<?php echo e(asset('public/fontend/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/fontend/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/fontend/css/prettyPhoto.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/fontend/css/price-range.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/fontend/css/animate.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('public/fontend/css/main.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/fontend/css/easyzoom.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('public/fontend/css/responsive.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/fontend/css/passtrength.css')); ?>" rel="stylesheet">

    <!--[if lt IE 9]>
    <script src="<?php echo e(asset('public/fontendLayout/')); ?>js/html5shiv.js"></script>
    <script src="<?php echo e(asset('public/fontendLayout/')); ?>js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="<?php echo e(asset('public/fontend/images/ico/favicon.ico')); ?>">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo e(asset('public/fontend/images/ico/apple-touch-icon-144-precomposed.png')); ?>">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo e(asset('public/fontend/images/ico/apple-touch-icon-114-precomposed.png')); ?>">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo e(asset('public/fontend/images/ico/apple-touch-icon-72-precomposed.png')); ?>">
    <link rel="apple-touch-icon-precomposed" href="<?php echo e(asset('public/fontend/images/ico/apple-touch-icon-57-precomposed.png')); ?>">
</head><!--/head-->

<body>
	<!--/header-->
    <?php echo $__env->make('layouts.fontendLayout.fontend_header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('layouts.fontendLayout.fontend_footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!--/Footer-->
    <script src="<?php echo e(asset('public/fontend/js/jquery.js')); ?>"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(asset('public/fontend/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/fontend/js/jquery.scrollUp.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/fontend/js/price-range.js')); ?>"></script>
    <script src="<?php echo e(asset('public/fontend/js/jquery.prettyPhoto.js')); ?>"></script>
    <script src="<?php echo e(asset('public/fontend/js/easyzoom.js')); ?>"></script>
    <script src="<?php echo e(asset('public/fontend/js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('public/fontend/js/jquery.validate.js')); ?>"></script>
    <script src="<?php echo e(asset('public/fontend/js/passtrength.js')); ?>"></script>
    
</body>
</html>