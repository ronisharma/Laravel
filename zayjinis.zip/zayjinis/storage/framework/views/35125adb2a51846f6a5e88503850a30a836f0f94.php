<?php $__env->startSection('content'); ?>
<div id="content">
  <div id="content-header">
    <div id="breadcrumb"> <a href="#" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#" class="current">view Coupon</a> </div>
    <h1>Coupon</h1>
  </div>
  	<?php if(Session::has('flash_message_success')): ?>
	<div class="alert alert-success alert-block">
	    <button type="button" class="close" data-dismiss="alert">×</button> 
	        <strong><?php echo session('flash_message_success'); ?></strong>
	</div>
	<?php endif; ?>
  <div class="container-fluid">
    <hr>
    <div class="row-fluid">
      <div class="span12">
        <div class="widget-box">
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
            <h5>View Coupon</h5>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-bordered data-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Coupon Code</th>
                  <th>Amount Type</th>
                  <th>Amount</th>
                  <th>Expiry Date</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
              <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="gradeX">
                  <td><?php echo e($value->id); ?></td>
                  <td><?php echo e($value->coupon_code); ?></td>
                  <td><?php echo e($value->amount_type); ?></td>
                  <td><?php echo e($value->amount); ?></td>
                  <td><?php echo e($value->expiry_date); ?></td>
                 
                  <td class="center">
                    <a href="#" class="btn btn-primary btn-mini"><?php echo e($value->status); ?></a>
                    <a href="<?php echo e(url('/admin/edit-coupon/'.$value->id)); ?>" class="btn btn-primary btn-mini">Edit</a> 
                    <a href="<?php echo e(url('/admin/delete-coupon/'.$value->id)); ?>" id="deleteCat" class="btn btn-danger btn-mini deleteRecord">Delete</a>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>