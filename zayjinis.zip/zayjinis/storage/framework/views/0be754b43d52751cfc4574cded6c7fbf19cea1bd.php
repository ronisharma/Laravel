<?php $__env->startSection('content'); ?>
		<!-- BREADCRUMB -->
	<div id="breadcrumb">
		<div class="container">
			<ul class="breadcrumb">
				<li><a href="#">Home</a></li>
				<li class="active">Shopping Cart</li>
			</ul>
		</div>
	</div>
	<!-- /BREADCRUMB -->

	<!-- section -->
	<div class="section">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<?php if(Session::has('flash_message_success')): ?>
		            <div class="alert alert-success alert-block">
		                <button type="button" class="close" data-dismiss="alert">×</button> 
		                    <strong><?php echo session('flash_message_success'); ?></strong>
		            </div>
		        <?php endif; ?>
		        <?php if(Session::has('flash_message_error')): ?>
		            <div class="alert alert-error alert-block" style="background-color:#f4d2d2">
		                <button type="button" class="close" data-dismiss="alert">×</button> 
		                    <strong><?php echo session('flash_message_error'); ?></strong>
		            </div>
        		<?php endif; ?>
			<div class="row">
				<form id="checkout-form" class="clearfix">
					<div class="col-md-12">
						<div class="order-summary clearfix">
							<div class="section-title">
								<h3 class="title">Cart Product</h3>
							</div>
							<table class="shopping-cart-table table">
								<thead>
									<tr>
										<th>Product</th>
										<th></th>
										<th class="text-center">Price</th>
										<th class="text-center">Quantity</th>
										<th class="text-center">Total</th>
										<th class="text-right">Remove</th>
									</tr>
								</thead>
								<tbody>
									<?php $total_amount = 0; ?>
									<?php $__currentLoopData = $userCart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td class="thumb"><img src="<?php echo e(asset('public/backend/products/small_image/'.$cart->image)); ?>" alt=""></td>
										<td class="details">
											<a href="#"><?php echo e($cart->product_name); ?></a>
											<ul>
												<li><span>Size: <?php echo e($cart->size); ?></span></li>
												<li><span>Color:<?php echo e($cart->product_color); ?></span></li>
											</ul>
										</td>
										<td class="price text-center"><strong>Tk <?php echo e($cart->price); ?></strong></td>
										<td class="qty text-center">
										<a class="cart_quantity_up" href="<?php echo e(url('/cart/update-quantity/'.$cart->id.'/1')); ?>"><b> + </b></a>
										<input class="input" type="text" value="<?php echo e($cart->quantity); ?>" autocomplete="off" size="1">
										<?php if($cart->quantity>1): ?>
											<a class="cart_quantity_down" href="<?php echo e(url('/cart/update-quantity/'.$cart->id.'/-1')); ?>"><b> - </b></a>
										<?php endif; ?>
										</td>
										<td class="total text-center"><strong class="primary-color">TK <?php echo e($cart->price*$cart->quantity); ?></strong></td>
										<td class="text-right">
										<a class="cart_quantity_delete" href="<?php echo e(url('/cart/delete-product/'.$cart->id)); ?>"><i class="fa fa-close"></i>
										</a></td>
									</tr>
									<?php $total_amount = $total_amount + ($cart->price*$cart->quantity); ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
								<tfoot>
									<tr>
										<th class="empty" colspan="3"></th>
										<th>SUBTOTAL</th>
										<th colspan="2" class="sub-total">Tk. <?php echo $total_amount; ?></th>
									</tr>
									<tr>
										<th class="empty" colspan="3"></th>
										<th>SHIPING</th>
										<td colspan="2">Free Shipping</td>
									</tr>
									<tr>
										<th class="empty" colspan="3"></th>
										<th>TOTAL</th>
										<th colspan="2" class="total">Tk. <?php echo $total_amount; ?></th>
									</tr>
								</tfoot>
							</table>
							<div class="pull-right">
								<?php if($total_amount > 0): ?>
								<a class="primary-btn" href="<?php echo e(url('/checkout')); ?>">Check Out</a>
								<?php endif; ?>
							</div>
						</div>

					</div>
				</form>
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</div>
	<!-- /section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fontendLayout.fontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>