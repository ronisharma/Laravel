<?php $__env->startSection('content'); ?>
<div id="content">
  <div id="content-header">
    <div id="breadcrumb"> <a href="<?php echo e(url('/admin/dashboard')); ?>" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#">Product</a> <a href="#" class="current">add Images</a> </div>
    <h1>Product Images</h1>
  </div>
  <div class="container-fluid"><hr>
    <div class="row-fluid">
      <div class="span12">
      	<?php if(Session::has('flash_message_success')): ?>
			<div class="alert alert-success alert-block">
			    <button type="button" class="close" data-dismiss="alert">×</button> 
			        <strong><?php echo session('flash_message_success'); ?></strong>
			</div>
		  <?php endif; ?>
      <?php if(Session::has('flash_message_error')): ?>
      <div class="alert alert-success alert-block">
          <button type="button" class="close" data-dismiss="alert">×</button> 
              <strong><?php echo session('flash_message_error'); ?></strong>
      </div>
      <?php endif; ?>
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"> <i class="icon-info-sign"></i> </span>
            <h5>Add Image</h5>
          </div>
          
          <div class="widget-content nopadding">
            <form enctype="multipart/form-data" class="form-horizontal" method="post" action="<?php echo e(url('admin/add-images/'.$productDetails->id)); ?>" name="add_product" id="add_product" novalidate="novalidate"><?php echo e(csrf_field()); ?>

              <input type="hidden" name="product_id" value="<?php echo e($productDetails->id); ?>">
              <div class="control-group">
                <label class="control-label">Category Name</label>
                <label class="control-label"><?php echo e($category_name->name); ?></label>
              </div>
              <div class="control-group">
                <label class="control-label">Product Name</label>
                <label class="control-label"><?php echo e($productDetails->product_name); ?></label>
              </div>
              <div class="control-group">
                <label class="control-label">Product Code</label>
                <label class="control-label"><?php echo e($productDetails->product_code); ?></label>
              </div>
              <div class="control-group">
                <label class="control-label">Product Alt Image(s)</label>
                <div class="controls">
                  <div class="uploader" id="uniform-undefined"><input name="image[]" id="image" type="file" multiple="multiple"></div>
                </div>
              </div>
             
              <div class="form-actions">
                <input type="submit" value="Add Images" class="btn btn-success">
              </div>
            </form>
          </div>
        </div>

      </div>
      <!--view attribute-->
      <div class="row-fluid">
      <div class="span12">
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
            <h5>Images</h5>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-bordered data-table">
              <thead>
                <tr>
                  <th>Image ID</th>
                  <th>Product ID</th>
                  <th>Image</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="gradeX">
                  <td class="center"><?php echo e($image->id); ?></td>
                  <td class="center"><?php echo e($image->product_id); ?></td>
                  <td class="center"><img width="80" height="60" src="<?php echo e(asset('public/backend/products/small_image/'.$image->image)); ?>"></td>
                  <td class="center"><a id="delImage" rel="<?php echo e($image->id); ?>" rel1="delete-alt-image" href="javascript:" class="btn btn-danger btn-mini deleteRecord">Delete</a></td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
    </div><!--end view attribute-->
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>