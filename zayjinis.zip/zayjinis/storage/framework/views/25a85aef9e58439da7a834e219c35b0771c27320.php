<?php $__env->startSection('content'); ?>
<div id="content">
  <div id="content-header">
    <div id="breadcrumb"> <a href="#" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#" class="current">view Order</a> </div>
    <h1>Order</h1>
  </div>
  	<?php if(Session::has('flash_message_success')): ?>
	<div class="alert alert-success alert-block">
	    <button type="button" class="close" data-dismiss="alert">×</button> 
	        <strong><?php echo session('flash_message_success'); ?></strong>
	</div>
	<?php endif; ?>
  <div class="container-fluid">
    <div class="row-fluid">
      <div class="span12">
        <div class="widget-box">
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
            <h5>View Order</h5>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-bordered data-table">
              <thead>
                <tr>
                  <th>OrderID</th>
                  <th>Order Date</th>
                  <th>Customer Name</th>
                  <th>Customer Email</th>
                  <th>Ordered Product</th>
                  <th>Ordered Amount</th>
                  <th>Order Status</th>
                  <th>Payment Method</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
              <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="gradeX">
                  <td><?php echo e($value->id); ?></td>
                  <td><?php echo e($value->created_at); ?></td>
                  <td><?php echo e($value->name); ?></td>
                  <td><?php echo e($value->user_email); ?></td>
                  <td>
                      <?php $__currentLoopData = $value->orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php echo e($pro->product_code); ?> 
                      (<?php echo e($pro->product_qty); ?>)
                      <br>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </td>
                  <td><?php echo e($value->grand_total); ?></td>
                  <td><?php echo e($value->order_status); ?></td>
                  <td><?php echo e($value->payment_method); ?></td>
                 
                  <td class="center">
                    <a href="<?php echo e(url('admin/order-details/'.$value->id)); ?>" class="btn btn-success btn-mini">Details</a>
            
                    <a rel="<?php echo e($value->id); ?>" rel1="delete-product" href="javascript:" class="btn btn-danger btn-mini deleteRecord">Delete</a>
                  </td>
                </tr>
               
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>