<?php $__env->startSection('content'); ?>
<div id="content">
  <div id="content-header">
    <div id="breadcrumb"> <a href="<?php echo e(url('/admin/dashboard')); ?>" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#">Slider</a> <a href="#" class="current">add Slider</a> </div>
    <h1>Slider</h1>
  </div>
  <div class="container-fluid"><hr>
    <div class="row-fluid">
      <div class="span12">
      	<?php if(Session::has('flash_message_success')): ?>
			<div class="alert alert-success alert-block">
			    <button type="button" class="close" data-dismiss="alert">×</button> 
			        <strong><?php echo session('flash_message_success'); ?></strong>
			</div>
		  <?php endif; ?>
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"> <i class="icon-info-sign"></i> </span>
            <h5>Add Slider</h5>
          </div>
          
          <div class="widget-content nopadding">
            <form class="form-horizontal" method="post" action="<?php echo e(url('/admin/add-slider')); ?>" name="add_slider" id="add_slider" novalidate="novalidate" enctype="multipart/form-data"><?php echo e(csrf_field()); ?>

              <div class="control-group">
                <label class="control-label">Slider Name</label>
                <div class="controls">
                  <input type="text" name="name" id="name">
                </div>
              </div>
              <div class="control-group">
                <label class="control-label"> Link</label>
                <div class="controls">
                  <input type="text" name="link" id="link">
                </div>
              </div>
              
              <div class="control-group">
                <label class="control-label">Image</label>
                <div class="controls">
                  <input type="file" name="image" id="image" required="">
                </div>
              </div>
              <div class="control-group">
              <label class="control-label">Enable</label>
                <div class="controls">
                  <input type="checkbox" name="status" id="status" value="1">
                </div>
              </div>
              <div class="form-actions">
                <input type="submit" value="Add Slider" class="btn btn-success">
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>