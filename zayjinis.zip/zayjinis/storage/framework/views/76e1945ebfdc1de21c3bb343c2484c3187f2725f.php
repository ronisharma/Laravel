<?php $__env->startSection('content'); ?>
	
	<section id="form" style="margin-top: 10px;"><!--form-->
		<div class="container">
			<div class="breadcrumbs">
				<ol class="breadcrumb">
				  <li><a href="#">Home</a></li>
				  <li class="active">Order Review</li>
				</ol>
			</div>
			<div class="row">
				<div class="col-sm-4 col-sm-offset-1">
					<div class="login-form"><!--login form-->
						<h3>Billing Address</h3>		
						<div class="form-group">				
							<?php echo e($userDetails->name); ?>

						</div>
						<div class="form-group">
							<?php echo e($userDetails->address); ?>

						</div>
						<div class="form-group">
							<?php echo e($userDetails->country); ?>

						</div>
						<div class="form-group">
							<?php echo e($userDetails->city); ?>

						</div>
						<div class="form-group">
							<?php echo e($userDetails->state); ?>

						</div>
						
						<div class="form-group">
						<?php echo e($userDetails->pincode); ?>

						</div>
						<div class="form-group">
							<?php echo e($userDetails->mobile); ?>

						</div>
					</div>
				</div>
				<div class="col-sm-1">
					<h3 class="or">OR</h3>
				</div>
				<div class="col-sm-4">
					<div class="signup-form"><!--sign up form-->
						<h3>Shipping Address</h3>						
						  <div class="form-group">				
							<?php echo e($shippingDetails->name); ?>

						   </div>
						<div class="form-group">
							<?php echo e($shippingDetails->address); ?>

						</div>
						<div class="form-group">
							<?php echo e($shippingDetails->country); ?>

						</div>
						<div class="form-group">
							<?php echo e($shippingDetails->city); ?>

						</div>
						<div class="form-group">
							<?php echo e($shippingDetails->state); ?>

						</div>
						<div class="form-group">
							<?php echo e($shippingDetails->pincode); ?>

						</div>
						<div class="form-group">
							<?php echo e($shippingDetails->mobile); ?>

						</div>	
							
					</div>
				</div>
			</div>
			<!--start review here-->
	<section id="cart_items">
		<div class="container">			
			<div class="review-payment">
				<h2>Review & Payment</h2>
			</div>
			<div class="table-responsive cart_info">
				<table class="table table-condensed">
					<thead>
						<tr class="cart_menu">
							<td class="image">Item</td>
							<td class="description"></td>
							<td class="price">Price</td>
							<td class="quantity">Quantity</td>
							<td class="total">Total</td>
							
						</tr>
					</thead>
					<tbody>
						<?php $total_amount = 0; ?>
						<?php $__currentLoopData = $userCart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td class="cart_product">
								<a href=""><img style="width:100px;" src="<?php echo e(asset('/public/backend/products/small_image/'.$cart->image)); ?>" alt=""></a>
							</td>
							<td class="cart_description">
								<h4><a href=""><?php echo e($cart->product_name); ?></a></h4>
								<p>Product Code: <?php echo e($cart->product_code); ?></p>
							</td>
							<td class="cart_price">
								<p>TK <?php echo e($cart->price); ?></p>
							</td>
							<td class="cart_quantity">
								<div class="cart_quantity_button">
									<?php echo e($cart->quantity); ?>

								</div>
							</td>
							<td class="cart_total">
								<p class="cart_total_price">TK <?php echo e($cart->price*$cart->quantity); ?></p>
							</td>
							
						</tr>
						<?php $total_amount = $total_amount + ($cart->price*$cart->quantity); ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td colspan="4">&nbsp;</td>
							<td colspan="2">
								<table class="table table-condensed total-result">
									<tr>
										<td>Cart Sub Total</td>
										<td>Tk <?php echo e($total_amount); ?></td>
									</tr>
									<tr>
										<td>Discount (-)</td>
										<td>
											<?php if(!empty(Session::get('couponAmount'))): ?>
											Tk <?php echo e(Session::get('couponAmount')); ?>

											<?php else: ?>
												Tk 0
											<?php endif; ?>
										</td>
									</tr>
									<tr class="shipping-cost">
										<td>Shipping Cost (+)</td>
										<td>Tk 0</td>										
									</tr>
									<tr>
										<td>Grand Total</td>
										<td><span>Tk <?php echo e($grand_total = $total_amount - Session::get('couponAmount')); ?></span></td>
									</tr>
								</table>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			<form method="post" action="<?php echo e(url('/place-order')); ?>"><?php echo e(csrf_field()); ?>

				<div class="payment-options">
					<span>
						<input type="hidden" name="grand_total" value="<?php echo e($grand_total); ?>">
						<label><strong>Select Payment Method</strong></label>
					</span>
					<span>
						<label><input type="radio" name="payment" id="bkash" value="bkash"><b> bkash</b></label>
					</span>
					<span>
						<label><input type="radio" name="payment" id="cod" value="cod"><b> Cash-on Delivery</b></label>
					</span>
					<span>
						<button class="btn btn-success" onclick="return placeorder()" style="float: right;">Place Order</button>
					</span>
				</div>
			</form>
		</div>
	</section><!--end review here-->
		
		</div>
	</section>

<?php $__env->stopSection(); ?>
	
	
<?php echo $__env->make('layouts.fontendLayout.fontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>