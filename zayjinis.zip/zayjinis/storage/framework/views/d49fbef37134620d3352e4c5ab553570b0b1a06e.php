<?php $__env->startSection('content'); ?>
	
	<section id="form" style="margin-top: 50px;"><!--form-->
		<div class="container">
			<div class="row">
					<?php if(Session::has('flash_message_success')): ?>
		            <div class="alert alert-success alert-block">
		                <button type="button" class="close" data-dismiss="alert">×</button> 
		                    <strong><?php echo session('flash_message_success'); ?></strong>
		            </div>
		       		<?php endif; ?>
					<?php if(Session::has('flash_message_error')): ?>
		            <div class="alert alert-success alert-block">
		                <button type="button" class="close" data-dismiss="alert">×</button> 
		                    <strong><?php echo session('flash_message_error'); ?></strong>
		            </div>
		       		<?php endif; ?>
				<div class="col-sm-4 col-sm-offset-1">
					<div class="login-form"><!--login form-->
						<h3>Update account</h3>
						<form action="<?php echo e(url('/account')); ?>" method="post" name="updateUser" id="updateUser"><?php echo e(csrf_field()); ?>

							<input type="text" name="name" value="<?php echo e($userDetails->name); ?>" class="form-control" id="name" placeholder="Name"/><br>
							<input type="text" name="address" value="<?php echo e($userDetails->address); ?>" class="form-control" id="address" placeholder="Enter Address"/><br>
							<select name="country" class="form-control" id="country">
								<option value="">Select One</option>
								<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($country->country_name); ?>" <?php if($country->country_name==$userDetails->country): ?> selected <?php endif; ?> ><?php echo e($country->country_name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select><br>
							<input type="text" name="city" value="<?php echo e($userDetails->city); ?>" class="form-control" id="city" placeholder="city"><br>
							<input type="state" name="state" value="<?php echo e($userDetails->state); ?>" class="form-control" id="state" placeholder="state"><br>
							<input type="text" name="pincode" value="<?php echo e($userDetails->pincode); ?>" class="form-control" id="pincode" placeholder="pincode"><br>
							<input type="text" name="mobile" value="<?php echo e($userDetails->mobile); ?>" class="form-control" id="mobile" placeholder="Mobile"><br>
							<button type="submit" class="btn btn-default">Update</button>
						</form>
					</div><!--/login form-->
				</div>
				<div class="col-sm-1">
					<h3 class="or">OR</h3>
				</div>
				<div class="col-sm-4">
					<div class="signup-form"><!--sign up form-->
						<h3>Update Password</h3>
						<form action="<?php echo e(url('/updateUserpwd')); ?>" method="post" name="updateuserPwd" id="updateuserPwd"><?php echo e(csrf_field()); ?>

							<input type="password" name="current_pwd" class="form-control" id="current_pwd" placeholder="Current Password"/><br>
							<span id="pwdchk"></span>
							<input type="password" name="new_pwd" class="form-control" id="new_pwd" placeholder="New Password"><br>
							<input type="password" name="confirm_pwd" class="form-control" id="confirm_pwd" placeholder="Confirm Password"><br>
							<button type="submit" class="btn btn-default">Update Password</button>
						</form>
						
					</div><!--/sign up form-->
				</div>
			</div>
		</div>
	</section><!--/form-->

<?php $__env->stopSection(); ?>
	
	
<?php echo $__env->make('layouts.fontendLayout.fontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>