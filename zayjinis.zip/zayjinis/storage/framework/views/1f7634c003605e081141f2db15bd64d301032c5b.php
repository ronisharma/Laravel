<?php
use App\Models\CategoryModel;
use App\Http\Controllers\Controller;
use App\Http\Controllers\IndexController;

$mainCategories = Controller::mainCategories();
$cart = IndexController::carts();
//var_dump($cart);exit();
?>
<!-- HEADER -->
    <header>
        <!-- top Header -->
        <div id="top-header">
            <div class="container">
                <div class="pull-left">
                    <span><marquee>শীঘ্রই শুভ উদ্বোধন হচ্ছে Zayjinis.com</marquee></span>
                </div>
                <div class="pull-right">
                    <ul class="footer-social">
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                        <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- /top Header -->

        <!-- header -->
        <div id="header">
            <div class="container">
                <div class="pull-left">
                    <!-- Logo -->
                    <div class="header-logo">
                        <a class="logo" href="<?php echo e(url('/')); ?>">
                            <img src="<?php echo e(asset('public/fontend/logo.png')); ?>" alt="">
                        </a>
                    </div>
                    <!-- /Logo -->

                    <!-- Search -->
                    <div class="header-search">
                        <form method="post" action="<?php echo e(url('/search-product')); ?>"><?php echo e(csrf_field()); ?>

                            <input class="input search-input" type="text" name="name" placeholder="Enter your keyword">
                            <select name="cat_id" class="input search-categories">
                                <option value="0">Select One</option>
                                <?php $__currentLoopData = $mainCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <button class="search-btn"><i class="fa fa-search"></i></button>
                        </form>
                    </div>
                    <!-- /Search -->
                </div>
                <div class="pull-right">
                    <ul class="header-btns">
                        <!-- Account -->
                        <li class="header-account dropdown default-dropdown">
                            <div class="dropdown-toggle" role="button" data-toggle="dropdown" aria-expanded="true">
                                <div class="header-btns-icon">
                                    <i class="fa fa-user-o"></i>
                                </div>
                                <strong class="text-uppercase">My Account <i class="fa fa-caret-down"></i></strong>
                            </div>
                            <?php if(empty(Auth::check())): ?>
                            <a href="<?php echo e(url('/login-register')); ?>" class="text-uppercase">Login</a> / <a href="<?php echo e(url('/login-register')); ?>" class="text-uppercase">Join</a>
                            <?php else: ?>
                            <a href="<?php echo e(url('/user-logout')); ?>" class="text-uppercase">LogOut</a>
                            <?php endif; ?>
                            <ul class="custom-menu">
                                <?php if(empty(Auth::check())): ?>
                                <li><a href="<?php echo e(url('/login-register')); ?>"><i class="fa fa-unlock-alt"></i> Login</a></li>
                                <li><a href="<?php echo e(url('/login-register')); ?>"><i class="fa fa-user-plus"></i> Create An Account</a>
                                </li>
                                <?php else: ?>
                                <li><a href="<?php echo e(url('/account')); ?>"><i class="fa fa-user-o"></i> My Account</a></li>
                                <li><a href="<?php echo e(url('/user-order')); ?>"><i class="fa fa-heart-o"></i> My Order</a></li>
                                <li><a href="<?php echo e(url('/user-logout')); ?>"><i class="fa fa-key-o"></i> Logout</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                        <!-- /Account -->

                        <!-- Cart -->
                        <li class="header-cart dropdown default-dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
                                <div class="header-btns-icon">
                                    <i class="fa fa-shopping-cart"></i>
                                    <!-- <span class="qty"></span> -->
                                </div>
                                <strong class="text-uppercase">My Cart:</strong>
                                <br>
                                <span><?php echo e(Session::get('grand_total')); ?></span>
                            </a>
                            <div class="custom-menu">
                                <div id="shopping-cart">
                                    <div class="shopping-cart-list">
                                        <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="product product-widget">
                                            <div class="product-thumb">
                                                <img src="<?php echo e(asset('public/backend/products/small_image/'.$value->image)); ?>" alt="">
                                            </div>
                                            <div class="product-body">
                                                <h3 class="product-price">Tk. <?php echo e($value->price); ?> <span class="qty">x <?php echo e($value->quantity); ?></span></h3>
                                                <h2 class="product-name"><a href="#"><?php echo e($value->product_name); ?></a></h2>
                                            </div>
                                            
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <!-- <div class="product product-widget">
                                            <div class="product-thumb">
                                                <img src="<?php echo e(asset('public/fontend/img/thumb-product01.jpg')); ?>" alt="">
                                            </div>
                                            <div class="product-body">
                                                <h3 class="product-price">$32.50 <span class="qty">x3</span></h3>
                                                <h2 class="product-name"><a href="#">Product Name Goes Here</a></h2>
                                            </div>
                                            <button class="cancel-btn"><i class="fa fa-trash"></i></button>
                                        </div> -->
                                    </div>
                                    <div class="shopping-cart-btns">
                                        <button class="primary-btn"><a href="<?php echo e(url('/cart')); ?>">View Cart</a></button>
                                        <button class="primary-btn"><a href="<?php echo e(url('/checkout')); ?>">Checkout <i class="fa fa-arrow-circle-right"></i></a></button>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <!-- /Cart -->

                        <!-- Mobile nav toggle-->
                        <li class="nav-toggle">
                            <button class="nav-toggle-btn main-btn icon-btn"><i class="fa fa-bars"></i></button>
                        </li>
                        <!-- / Mobile nav toggle -->
                    </ul>
                </div>
            </div>
            <!-- header -->
        </div>
        <!-- container -->
    </header>
    <!-- /HEADER -->

    <!-- NAVIGATION -->
    <div id="navigation">
        <!-- container -->
        <div class="container">
            <div id="responsive-nav">
                <!-- category nav -->
                <div class="category-nav <?php if($navbar==''): ?>show-on-click <?php endif; ?>">
                    <span class="category-header">Categories <i class="fa fa-list"></i></span>
                    <ul class="category-list">
                    	<?php $__currentLoopData = $mainCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="dropdown side-dropdown">
                            <a class="dropdown-toggle" href="hello" data-toggle="dropdown" aria-expanded="true"><?php echo e($category->name); ?><i class="fa fa-angle-right"></i></a>
                            <div class="custom-menu">
                                <div class="row">
                                    <div class="col-md-12">
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">Subcategory</h3></li>
                                            <?php $__currentLoopData = $category->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="<?php echo e(url('/product/'.$subcategory->url)); ?>"><?php echo e($subcategory->name); ?></a></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        <hr class="hidden-md hidden-lg">
                                    </div>
                                </div>
                                
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				 <!--   <li><a href="#">Category two</a></li>
                        <li class="dropdown side-dropdown"><a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">Category Three <i class="fa fa-angle-right"></i></a>
                            <div class="custom-menu">
                                <div class="row">
                                    <div class="col-md-4">
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">Subcategory</h3></li>
                                            <li><a href="#">Women’s Clothing</a></li>
                                            <li><a href="#">Men’s Clothing</a></li>
                                            <li><a href="#">Phones & Accessories</a></li>
                                            <li><a href="#">Jewelry & Watches</a></li>
                                            <li><a href="#">Bags & Shoes</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li><a href="#">Category Four</a></li>
                        <li><a href="#">Category Five</a></li> -->
                        
                    </ul>
                </div>
                <!-- /category nav -->

                <!-- menu nav -->
                <div class="menu-nav">
                    <span class="menu-header">Menu <i class="fa fa-bars"></i></span>
                    <ul class="menu-list">
                        <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li><a href="#">About Us</a></li>
                        <li class="dropdown default-dropdown"><a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">Shop <i class="fa fa-caret-down"></i></a>
                            <ul class="custom-menu">
                                <?php $__currentLoopData = $mainCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(url('product/'.$category->url)); ?>"><?php echo e($category->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                        <li><a href="#">Contact Us</a></li>
                    </ul>
                </div>
                <!-- menu nav -->
            </div>
        </div>
        <!-- /container -->
    </div>
    <!-- /NAVIGATION -->
    <style type="text/css">
        .pull-left {
            float: left;
            width: 70%;
        }
        .pull-left span{
            color: green;
        }
    </style>