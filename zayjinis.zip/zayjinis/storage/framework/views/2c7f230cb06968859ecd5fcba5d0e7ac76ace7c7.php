<?php $__env->startSection('content'); ?>
	<section id="cart_items">
		<div class="container">
			<div class="breadcrumbs">
				<ol class="breadcrumb">
				  <li><a href="#">Home</a></li>
				  <li class="active">Thanks</li>
				</ol>
			</div>
		</div>
	</section> <!--/#cart_items-->
	<section id="do_action" style="text-align: center;">
		<div class="container">
			<div class="heading">
				<h3>Your Order Has Been Placed</h3>
				<p>Yore Order Number is #0<?php echo e(Session::get('order_id')); ?># and Total Payable is <?php echo e(Session::get('grand_total')); ?> Tk</p>
			</div>
		</div>
	</section><!--/#do_action-->
<?php $__env->stopSection(); ?>

<?php
Session::forget('order_id');
Session::forget('grand_total');
?>
<?php echo $__env->make('layouts.fontendLayout.fontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>