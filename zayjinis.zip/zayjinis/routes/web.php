<?php
Schema::defaultStringLength(191);
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });
//===Fondend===//
Route::get('/','IndexController@index');
Route::get('/product/{url}','IndexController@product');
Route::get('/product-details/{id}','IndexController@productDetails');
Route::post('/get-product-price','IndexController@getproductPrice');
Route::post('/search-product','IndexController@searchProduct');

Route::post('/add-to-cart','IndexController@addCart');
Route::match(['get','post'],'/cart','IndexController@cart');
Route::get('/cart/delete-product/{id}','IndexController@deleteCart');
Route::get('/cart/update-quantity/{id}/{quantity}','IndexController@updateQuantity');

Route::post('/cart/apply-coupon','IndexController@applyCoupon');

Route::get('/login-register','UserController@loginRegister');
Route::match(['get','post'],'/check-email','UserController@checkEmail');

Route::post('/user-register','UserController@register');
Route::post('/user-login','UserController@login');

//==all route after login==//
Route::group(['middleware'=> ['fontlogin']],function(){
	Route::match(['get','post'],'/account','UserController@account');
	Route::get('/userpwdCheck','UserController@userpwdCheck');
	Route::post('/updateUserpwd','UserController@updateUserpwd');
	Route::match(['get','post'],'/checkout','IndexController@checkout');
	Route::match(['get','post'],'/order-review','IndexController@orderReview');
	Route::match(['get','post'],'/place-order','IndexController@placeOrder');
	Route::match(['get','post'],'/thanks','IndexController@thanks');
	Route::match(['get','post'],'/user-order','UserController@userOrder');
	Route::match(['get','post'],'/user-order/{id}','UserController@userOrderDetails');
});

Route::get('/user-logout','UserController@userLogout');


//====Admin====//
//Route::get('/admin','AdminController@login');
Route::match(['get','post'],'/admin','AdminController@login');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::group(['middleware' => ['auth']],function(){
	Route::get('/admin/dashboard','AdminController@dashboard');
	Route::get('/admin/setting','AdminController@setting');
	Route::post('/admin/checkpwd','AdminController@chkpassword');
	Route::match(['get','post'],'/admin/update-pwd','AdminController@updatePassword');

	//===Category Route===//
	Route::match(['get','post'],'/admin/add-category','CategoryController@addCategory');
	Route::get('/admin/view-category','CategoryController@viewCategory');
	Route::match(['get','post'],'/admin/edit-category/{id}','CategoryController@editCategory');
	Route::match(['get','post'],'/admin/delete-category/{id}','CategoryController@deleteCategory');

	//===Products Route===//
	Route::match(['get','post'],'/admin/add-product','ProductController@addProduct');
	Route::get('/admin/view-product','ProductController@viewProduct');
	Route::match(['get','post'],'/admin/edit-product/{id}','ProductController@editProduct');
	Route::match(['get','post'],'/admin/delete-product/{id}','ProductController@deleteProduct');
	Route::get('/admin/delete-product-image/{id}','ProductController@deleteProductimage');
	Route::get('/admin/delete-product/{id}','ProductController@deleteProduct');

	//===Product Attributes===//
	Route::match(['get','post'],'/admin/add-attribute/{id}','ProductController@addAttributes');
	Route::match(['get','post'],'/admin/edit-attribute/{id}','ProductController@editAttributes');
	Route::get('/admin/delete-attribute','ProductController@deleteAttribute');
	Route::match(['get','post'],'/admin/add-images/{id}','ProductController@addImages');

	//===Coupons Route===//
	Route::match(['get','post'],'/admin/add-coupon','CouponController@addCoupon');
	Route::match(['get','post'],'/admin/view-coupon','CouponController@viewCoupon');
	Route::match(['get','post'],'/admin/edit-coupon/{id}','CouponController@editCoupon');
	Route::get('/admin/delete-coupon/{id}','CouponController@deleteCoupon');

	//===Orders===//
	Route::match(['get','post'],'/admin/view-order','ProductController@viewOrder');
	Route::get('/admin/order-details/{id}','ProductController@orderDetails');

	//===Slider Route===//
	Route::match(['get','post'],'/admin/add-slider','SliderController@addSlider');
	Route::match(['get','post'],'/admin/view-slider','SliderController@viewSlider');
	Route::match(['get','post'],'/admin/edit-slider/{id}','SliderController@editSlider');
	Route::get('/admin/delete-slider/{id}','SliderController@deleteSlider');
});
	
Route::get('/logout','AdminController@logout');
